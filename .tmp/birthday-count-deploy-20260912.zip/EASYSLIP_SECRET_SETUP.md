# คู่มือตั้งค่า EASYSLIP_API_KEY ใน Supabase

## คำถามที่พบบ่อย

### Q: มี 2 อัน (`EASYSLIP_API_KEY` และ `EASYSLIP_ACCESS_TOKEN`) อันไหนถูกต้อง?

**A:** ใช้ `EASYSLIP_API_KEY` เท่านั้น

**เหตุผล:**
- โค้ด Edge Function ใช้ `EASYSLIP_API_KEY` เท่านั้น
- `EASYSLIP_ACCESS_TOKEN` ไม่ได้ถูกใช้งานในโค้ด
- ถ้ามีทั้งสองตัว อาจทำให้สับสน

---

## วิธีแก้ไข

### วิธีที่ 1: ลบทั้งสองแล้วสร้างใหม่ (แนะนำ)

**ขั้นตอน:**

1. **ลบ Secrets เก่า:**
   - คลิกที่ปุ่ม "..." ด้านขวาของ `EASYSLIP_API_KEY`
   - เลือก "Delete" หรือ "Remove"
   - ยืนยันการลบ
   - ทำซ้ำสำหรับ `EASYSLIP_ACCESS_TOKEN`

2. **สร้าง Secret ใหม่:**
   - ในช่อง "Name" ใส่: `EASYSLIP_API_KEY`
   - ในช่อง "Value" ใส่: API Key จาก EasySlip
   - คลิก "Save"

### วิธีที่ 2: ลบเฉพาะ `EASYSLIP_ACCESS_TOKEN`

**ขั้นตอน:**

1. **ลบ `EASYSLIP_ACCESS_TOKEN`:**
   - คลิกที่ปุ่ม "..." ด้านขวาของ `EASYSLIP_ACCESS_TOKEN`
   - เลือก "Delete" หรือ "Remove"
   - ยืนยันการลบ

2. **ตรวจสอบ `EASYSLIP_API_KEY`:**
   - ตรวจสอบว่าค่าถูกต้อง
   - ถ้าต้องการแก้ไข คลิกที่ปุ่ม "..." → "Edit"
   - แก้ไขค่าแล้วคลิก "Save"

---

## วิธีหา EasySlip API Key

### จาก EasySlip Dashboard:

1. **เข้า EasySlip Dashboard:**
   - ไปที่ https://developer.easyslip.com
   - Login เข้าสู่ระบบ

2. **หา API Key:**
   - ไปที่เมนู "API" หรือ "API Keys"
   - Copy API Key
   - ⚠️ **ระวัง: อย่าเปิดเผย API Key**

### ถ้าไม่มี API Key:

- สร้าง API Key ใหม่ใน EasySlip Dashboard
- หรือติดต่อ EasySlip Support: support@easyslip.com

---

## วิธีใส่ค่า API Key ใน Supabase

### ขั้นตอน:

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ `zkzjbhvsltbwbtteihiy`

2. **ไปที่ Settings → Edge Functions → Secrets:**
   - คลิกที่เมนู **Settings** ด้านซ้าย
   - คลิกที่ **Edge Functions**
   - คลิกแท็บ **Secrets**

3. **ใส่ค่า API Key:**
   - **Name:** ใส่ `EASYSLIP_API_KEY` (ต้องตรงกับชื่อนี้)
   - **Value:** ใส่ API Key จาก EasySlip (paste ค่าในช่อง "Value" ที่มีกรอบสีแดง)
   - ⚠️ **หมายเหตุ:** ข้อความ "Secrets can't be retrieved once saved" เป็นปกติ - หลังจาก Save แล้วจะไม่เห็นค่าเดิมอีก
   - คลิก **"Save"**

4. **ตรวจสอบ:**
   - ดูในรายการ Secrets ว่า `EASYSLIP_API_KEY` ถูกเพิ่มแล้ว
   - ตรวจสอบว่า "UPDATED" แสดงวันที่/เวลาล่าสุด

---

## Checklist

### การตั้งค่า:
- [ ] ลบ `EASYSLIP_ACCESS_TOKEN` (ถ้ามี)
- [ ] ตรวจสอบหรือสร้าง `EASYSLIP_API_KEY` ใหม่
- [ ] ใส่ค่า API Key ที่ถูกต้อง
- [ ] คลิก "Save"
- [ ] ตรวจสอบว่า Secret ถูกเพิ่มแล้ว

### การทดสอบ:
- [ ] Deploy Edge Function ใหม่ (ถ้าจำเป็น)
- [ ] ทดสอบการเชื่อมต่อจากหน้า Settings
- [ ] ตรวจสอบผลลัพธ์

---

## หมายเหตุ

⚠️ **สำคัญ:**
- ใช้ชื่อ `EASYSLIP_API_KEY` เท่านั้น (ไม่ใช่ `EASYSLIP_ACCESS_TOKEN`)
- อย่าเปิดเผย API Key
- ตรวจสอบว่า API Key ถูกต้องก่อน Save

📝 **คำแนะนำ:**
- ลบ `EASYSLIP_ACCESS_TOKEN` ออกเพื่อหลีกเลี่ยงความสับสน
- ใช้ `EASYSLIP_API_KEY` เท่านั้น
- เก็บ API Key ไว้ในที่ปลอดภัย

---

## Troubleshooting

### ปัญหา: ไม่เห็น Secret หลังจาก Save

**ตรวจสอบ:**
1. คลิก "Save" แล้วหรือยัง
2. มี error message หรือไม่
3. Refresh หน้าเว็บ

**วิธีแก้:**
- ตรวจสอบว่าคลิก "Save" แล้ว
- ดู error message (ถ้ามี)
- Refresh หน้าเว็บ (F5)

### ปัญหา: Secret ไม่ทำงาน

**ตรวจสอบ:**
1. ชื่อ Secret ถูกต้องหรือไม่ (`EASYSLIP_API_KEY`)
2. ค่า API Key ถูกต้องหรือไม่
3. Deploy Edge Function ใหม่แล้วหรือยัง

**วิธีแก้:**
- ตรวจสอบชื่อ Secret อีกครั้ง
- ตรวจสอบค่า API Key
- Deploy Edge Function ใหม่: `supabase functions deploy verify-slip`

---

## คำถามที่พบบ่อย

### Q: ต้อง Deploy Edge Function ใหม่หลังจากตั้งค่า Secret หรือไม่?

**A:** 
- โดยปกติ Supabase จะใช้ Secrets ที่ตั้งค่าไว้ทันที
- แต่ถ้ามีปัญหา ให้ Deploy ใหม่: `supabase functions deploy verify-slip`

### Q: ถ้ามี Secret หลายตัวที่มีชื่อคล้ายกันจะเกิดอะไรขึ้น?

**A:**
- Edge Function จะใช้ Secret ที่ชื่อตรงกับที่ระบุในโค้ดเท่านั้น
- ในกรณีนี้ ใช้ `EASYSLIP_API_KEY` เท่านั้น
- `EASYSLIP_ACCESS_TOKEN` จะไม่ถูกใช้งาน

### Q: จะรู้ได้อย่างไรว่า Secret ตั้งค่าถูกต้อง?

**A:**
- ทดสอบการเชื่อมต่อจากหน้า Settings
- ดู Logs ใน Supabase Dashboard → Edge Functions → verify-slip → Logs
- ทดสอบการตรวจสอบสลิปจริง
