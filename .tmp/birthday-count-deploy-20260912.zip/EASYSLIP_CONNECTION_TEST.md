# คู่มือทดสอบการเชื่อมต่อ EasySlip API

## สรุปการปรับปรุง

### 1. ✅ ปรับปรุง Error Message

**ก่อน:**
```
การยืนยันตัวตนล้มเหลว (HTTP 401): Invalid JWT

กรุณาตรวจสอบ:
1. ว่าคุณยังล็อกอินอยู่หรือไม่
2. Session token ยังใช้งานได้หรือไม่
3. Edge Function permissions
```

**หลัง:**
```
การยืนยันตัวตนล้มเหลว (HTTP 401)

สาเหตุ: Invalid JWT

วิธีแก้ไข:
1. ลองออกจากระบบและเข้าสู่ระบบใหม่
2. ตรวจสอบว่า Session token ยังใช้งานได้ (ไม่หมดอายุ)
3. ตรวจสอบว่า Edge Function ตั้งค่า Secrets ถูกต้องแล้ว
   - EASYSLIP_API_KEY
   - SERVICE_ROLE_KEY
4. ตรวจสอบ Logs ใน Supabase Dashboard → Edge Functions → verify-slip → Logs
```

### 2. ✅ เพิ่มฟังก์ชันทดสอบการเชื่อมต่อ

**ฟังก์ชันใหม่:** `testEasySlipConnection()`

**ตรวจสอบ:**
- ✅ Edge Function เข้าถึงได้หรือไม่
- ✅ Secrets ตั้งค่าแล้วหรือไม่ (EASYSLIP_API_KEY, SERVICE_ROLE_KEY)
- ✅ EasySlip API เชื่อมต่อได้หรือไม่

### 3. ✅ เพิ่มปุ่มทดสอบในหน้า Settings

**ตำแหน่ง:** หน้า Settings → ด้านบน (ก่อน Tabs)

**ฟีเจอร์:**
- ปุ่ม "ทดสอบการเชื่อมต่อ EasySlip API"
- แสดงผลลัพธ์การทดสอบแบบละเอียด
- แสดงสถานะแต่ละส่วน (Edge Function, Secrets, EasySlip API)

---

## วิธีใช้งาน

### 1. ทดสอบการเชื่อมต่อจากหน้า Settings

1. **เข้าไปที่หน้า Settings:**
   - ไปที่เมนู "ตั้งค่า" ในแอปพลิเคชัน

2. **คลิกปุ่ม "ทดสอบการเชื่อมต่อ EasySlip API":**
   - อยู่ด้านบนของหน้า Settings
   - รอสักครู่ให้การทดสอบเสร็จ

3. **ดูผลลัพธ์:**
   - ✅ **สำเร็จ:** แสดงสถานะทั้งหมดเป็นสีเขียว
   - ❌ **ล้มเหลว:** แสดงสถานะที่ล้มเหลวและวิธีแก้ไข

### 2. ตรวจสอบผลลัพธ์

**ผลลัพธ์ที่ควรเห็น:**

```
✅ การเชื่อมต่อ EasySlip API สำเร็จ

Edge Function: ✅ เข้าถึงได้
Secrets ตั้งค่าแล้ว: ✅ ตั้งค่าแล้ว
EasySlip API: ✅ เชื่อมต่อได้
```

**ถ้ามีปัญหา:**

```
❌ การเชื่อมต่อมีปัญหา:
- Edge Function ไม่สามารถเข้าถึงได้
- Secrets ยังไม่ได้ตั้งค่า (EASYSLIP_API_KEY, SERVICE_ROLE_KEY)
- EasySlip API ไม่สามารถเข้าถึงได้

Error: [รายละเอียด error]
```

---

## Deploy Edge Function ใหม่

**ต้อง Deploy Edge Function ใหม่เพื่อให้รองรับ method 'test':**

```powershell
cd e:\Web_App\TR-ERP
supabase functions deploy verify-slip
```

---

## Checklist

### การปรับปรุง:
- [x] ปรับปรุง Error Message ให้ชัดเจนขึ้น
- [x] เพิ่มฟังก์ชัน `testEasySlipConnection()`
- [x] เพิ่มปุ่มทดสอบในหน้า Settings
- [x] เพิ่ม handler สำหรับ method 'test' ใน Edge Function
- [ ] Deploy Edge Function ใหม่

### การทดสอบ:
- [ ] Deploy Edge Function ใหม่
- [ ] ทดสอบการเชื่อมต่อจากหน้า Settings
- [ ] ตรวจสอบผลลัพธ์
- [ ] ทดสอบการตรวจสอบสลิปจริง

---

## Troubleshooting

### ปัญหา: ปุ่มทดสอบไม่ทำงาน

**ตรวจสอบ:**
1. Edge Function Deploy แล้วหรือยัง
2. มี error ใน console หรือไม่
3. Session token ยังใช้งานได้หรือไม่

**วิธีแก้:**
- Deploy Edge Function ใหม่
- ตรวจสอบ console logs
- ลอง logout และ login ใหม่

### ปัญหา: แสดง "Secrets ยังไม่ได้ตั้งค่า"

**ตรวจสอบ:**
1. ตั้งค่า Secrets ใน Supabase Dashboard แล้วหรือยัง
2. Secrets ถูกต้องหรือไม่

**วิธีแก้:**
- ไปที่ Supabase Dashboard → Settings → Edge Functions → Secrets
- ตั้งค่า `EASYSLIP_API_KEY` และ `SERVICE_ROLE_KEY`
- Deploy Edge Function ใหม่

### ปัญหา: แสดง "EasySlip API ไม่สามารถเชื่อมต่อได้"

**ตรวจสอบ:**
1. `EASYSLIP_API_KEY` ถูกต้องหรือไม่
2. EasySlip service เปิดใช้งานแล้วหรือไม่

**วิธีแก้:**
- ตรวจสอบ `EASYSLIP_API_KEY` อีกครั้ง
- ตรวจสอบว่า EasySlip service เปิดใช้งานแล้ว
- ดู Logs ใน Supabase Dashboard

---

## หมายเหตุ

✅ **สำเร็จแล้ว:**
- ปรับปรุง Error Message แล้ว
- เพิ่มฟังก์ชันทดสอบการเชื่อมต่อแล้ว
- เพิ่มปุ่มทดสอบในหน้า Settings แล้ว

📝 **ขั้นตอนต่อไป:**
1. Deploy Edge Function ใหม่
2. ทดสอบการเชื่อมต่อจากหน้า Settings
3. ตรวจสอบผลลัพธ์
4. ทดสอบการตรวจสอบสลิปจริง
