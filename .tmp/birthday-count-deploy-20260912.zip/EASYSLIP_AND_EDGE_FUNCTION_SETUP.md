# คู่มือการตั้งค่า EasySlip และ Edge Functions

## ปัญหาที่พบ

1. **EasySlip ปิดใช้งาน**: เว็บ EasySlip แสดงข้อความ "คุณปิดใช้งานบริการ" และ toggle switch อยู่ในสถานะ off
2. **Edge Functions ยังไม่ได้ตั้งค่า**: ต้องตั้งค่า Secrets ใน Supabase

---

## ส่วนที่ 1: เปิดใช้งาน EasySlip

### ขั้นตอนการเปิดใช้งาน EasySlip:

1. **เข้าสู่ระบบ EasySlip**
   - ไปที่ https://developer.easyslip.com
   - Login เข้าสู่ระบบ

2. **เปิดใช้งานบริการ**
   - ไปที่หน้า Dashboard หรือ Settings
   - หา toggle switch ที่เขียนว่า **"เปิดการใช้งาน"** (Enable/Activate)
   - **กด toggle switch ให้เป็นสถานะ ON (สีเขียว)**
   - บันทึกการตั้งค่า

3. **ตรวจสอบสถานะ**
   - หลังจากเปิดใช้งานแล้ว ให้รีเฟรชหน้าเว็บ
   - ตรวจสอบว่าไม่มีข้อความ "คุณปิดใช้งานบริการ" แล้ว
   - ตรวจสอบว่า toggle switch อยู่ในสถานะ ON

### หมายเหตุ:
- ถ้าเปิดใช้งานแล้วยังปิดอยู่ อาจเป็นเพราะ:
  - Package/Plan หมดอายุ
  - ต้องเติมเงินหรือต่ออายุแพ็กเกจ
  - มีปัญหาเกี่ยวกับบัญชี

---

## ส่วนที่ 2: ตั้งค่า Edge Functions ใน Supabase

### ขั้นตอนการตั้งค่า:

#### 1. เปิด Supabase Dashboard
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ของคุณ

#### 2. ตั้งค่า Secrets สำหรับ Edge Functions

**ไปที่:** Settings → Edge Functions → Secrets

**ตั้งค่า Secrets ต่อไปนี้:**

##### a. EASYSLIP_API_KEY
- **ชื่อ:** `EASYSLIP_API_KEY`
- **ค่า:** API Key จาก EasySlip
- **วิธีหา API Key:**
  1. ไปที่ EasySlip Dashboard
  2. ไปที่เมนู "API" หรือ "API Keys"
  3. Copy API Key (ถ้ายังไม่มีให้สร้างใหม่)

##### b. SERVICE_ROLE_KEY
- **ชื่อ:** `SERVICE_ROLE_KEY`
- **ค่า:** Service Role Key จาก Supabase
- **วิธีหา:**
  1. ไปที่ Supabase Dashboard → Settings → API
  2. หา "service_role" secret key
  3. Copy ค่า (⚠️ **ระวัง: อย่าเปิดเผย key นี้**)

##### c. SUPABASE_URL
- **ชื่อ:** `SUPABASE_URL`
- **ค่า:** Project URL จาก Supabase
- **วิธีหา:**
  1. ไปที่ Supabase Dashboard → Settings → API
  2. Copy "Project URL" (เช่น `https://xxxxx.supabase.co`)

#### 3. วิธีตั้งค่า Secrets:

**วิธีที่ 1: ใช้ Supabase Dashboard (แนะนำ)**
1. ไปที่ **Settings** → **Edge Functions**
2. คลิกแท็บ **Secrets**
3. คลิก **Add new secret**
4. ใส่ชื่อและค่า:
   - Name: `EASYSLIP_API_KEY`
   - Value: `<your-easyslip-api-key>`
5. คลิก **Save**
6. ทำซ้ำสำหรับ `SERVICE_ROLE_KEY` และ `SUPABASE_URL`

**วิธีที่ 2: ใช้ Supabase CLI**
```bash
# ตั้งค่า EASYSLIP_API_KEY
supabase secrets set EASYSLIP_API_KEY=your-api-key-here

# ตั้งค่า SERVICE_ROLE_KEY
supabase secrets set SERVICE_ROLE_KEY=your-service-role-key-here

# ตั้งค่า SUPABASE_URL
supabase secrets set SUPABASE_URL=https://your-project.supabase.co
```

#### 4. Deploy Edge Function

**วิธีที่ 1: ใช้ Supabase Dashboard**
1. ไปที่ **Edge Functions** → **verify-slip**
2. คลิก **Deploy** หรือ **Update**

**วิธีที่ 2: ใช้ Supabase CLI**
```bash
# Deploy function
supabase functions deploy verify-slip

# หรือ deploy ทั้งหมด
supabase functions deploy
```

#### 5. ตรวจสอบว่า Deploy สำเร็จ

1. ไปที่ **Edge Functions** → **verify-slip**
2. ตรวจสอบว่า function อยู่ในสถานะ "Active"
3. ดู Logs เพื่อตรวจสอบว่าไม่มี errors

---

## ส่วนที่ 3: ตรวจสอบการตั้งค่า

### ตรวจสอบ EasySlip:
```bash
# ทดสอบ API Key
curl -X POST https://developer.easyslip.com/api/v1/verify \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"image": "base64-encoded-image"}'
```

### ตรวจสอบ Edge Function:
1. ไปที่ Supabase Dashboard → Edge Functions → verify-slip
2. ดู Logs เพื่อตรวจสอบว่า function ทำงานได้
3. ทดสอบโดยเรียกใช้จาก Frontend

---

## ส่วนที่ 4: Troubleshooting

### ปัญหา: EasySlip เปิดใช้งานแล้วแต่ยังปิดอยู่

**วิธีแก้:**
1. ตรวจสอบว่า Package/Plan ยังใช้งานได้
2. ตรวจสอบว่ามีการเติมเงินหรือไม่
3. ติดต่อ EasySlip Support

### ปัญหา: Edge Function ยังไม่ทำงาน

**ตรวจสอบ:**
1. ✅ Secrets ถูกตั้งค่าครบหรือไม่:
   - `EASYSLIP_API_KEY`
   - `SERVICE_ROLE_KEY`
   - `SUPABASE_URL`

2. ✅ Edge Function ถูก deploy แล้วหรือไม่

3. ✅ ดู Logs ใน Supabase Dashboard:
   - ไปที่ Edge Functions → verify-slip → Logs
   - ตรวจสอบ error messages

### ปัญหา: HTTP 401 Unauthorized

**สาเหตุที่เป็นไปได้:**
1. Session token หมดอายุ → ลอง logout และ login ใหม่
2. Edge Function permissions ไม่ถูกต้อง
3. `SERVICE_ROLE_KEY` ไม่ถูกต้อง

**วิธีแก้:**
1. ลอง logout และ login ใหม่ในแอป
2. ตรวจสอบว่า `SERVICE_ROLE_KEY` ถูกต้อง
3. ตรวจสอบ Edge Function logs

---

## Checklist การตั้งค่า

### EasySlip:
- [ ] Login เข้า EasySlip ได้
- [ ] เปิดใช้งานบริการ (toggle switch ON)
- [ ] มี API Key
- [ ] ทดสอบ API Key ใช้งานได้

### Supabase Edge Functions:
- [ ] ตั้งค่า `EASYSLIP_API_KEY` secret
- [ ] ตั้งค่า `SERVICE_ROLE_KEY` secret
- [ ] ตั้งค่า `SUPABASE_URL` secret
- [ ] Deploy Edge Function `verify-slip`
- [ ] ตรวจสอบ Logs ไม่มี errors

### ทดสอบ:
- [ ] อัปโหลดสลิปได้
- [ ] ตรวจสอบสลิปได้
- [ ] ไม่มี HTTP 401 errors

---

## หมายเหตุสำคัญ

⚠️ **Security:**
- อย่าเปิดเผย `SERVICE_ROLE_KEY` หรือ `EASYSLIP_API_KEY`
- อย่า commit secrets ลงใน git
- ใช้ environment variables หรือ Supabase Secrets เท่านั้น

📝 **การอัปเดต:**
- ถ้าเปลี่ยน API Key ให้อัปเดต Secret ใน Supabase
- ถ้าเปลี่ยน Service Role Key ให้อัปเดต Secret ใน Supabase
