# แก้ไขปัญหา HTTP 401 เมื่อเรียก Edge Function

## ปัญหาที่พบ

จาก Logs พบว่า:
- **HTTP 401** เมื่อเรียก Edge Function `verify-slip`
- JWT token มีอยู่และถูกต้อง (จาก log metadata)
- `expires_at: 1769525156` (timestamp ในอนาคต - ดูถูกต้อง)
- `role: "authenticated"` - มี authentication
- แต่ Edge Function ยัง return 401

**สาเหตุ:** Supabase อาจ reject request ก่อนถึง Edge Function code

---

## วิธีแก้ไข

### วิธีที่ 1: ตรวจสอบ Edge Function Settings ใน Dashboard

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ `zkzjbhvsltbwbtteihiy`

2. **ไปที่ Edge Functions → verify-slip → Settings:**
   - คลิกที่เมนู **Edge Functions** ด้านซ้าย
   - คลิกที่ function **verify-slip**
   - คลิกแท็บ **Settings** หรือ **Details**

3. **ตรวจสอบ Authentication Settings:**
   - ตรวจสอบว่ามี "Require authentication" หรือไม่
   - ถ้ามี ให้ปิด (uncheck)
   - หรือตั้งค่าให้ allow anonymous access

### วิธีที่ 2: ลอง Logout และ Login ใหม่

1. **ออกจากระบบ:**
   - ไปที่แอปพลิเคชัน
   - คลิก "ออกจากระบบ"

2. **เข้าสู่ระบบใหม่:**
   - Login เข้าสู่ระบบอีกครั้ง
   - รอให้ session token ถูกสร้างใหม่

3. **ทดสอบอีกครั้ง:**
   - ไปที่หน้า Settings
   - ทดสอบการเชื่อมต่อหรือการตรวจสอบสลิป

### วิธีที่ 3: ตรวจสอบ Session Token

1. **เปิด Browser DevTools:**
   - กด `F12` หรือ `Ctrl+Shift+I`
   - ไปที่แท็บ **Application** หรือ **Storage**

2. **ตรวจสอบ Session:**
   - ไปที่ **Local Storage** → `https://zkzjbhvsltbwbtteihiy.supabase.co`
   - ดู `sb-zkzjbhvsltbwbtteihiy-auth-token`
   - ตรวจสอบว่า token ยังมีอยู่และไม่หมดอายุ

3. **ลบ Session และ Login ใหม่:**
   - ลบ token ทั้งหมด
   - Login ใหม่

### วิธีที่ 4: ตรวจสอบว่า Session Token ถูกส่งไปถูกต้อง

1. **เปิด Browser DevTools:**
   - กด `F12`
   - ไปที่แท็บ **Network**

2. **ทดสอบการเชื่อมต่อ:**
   - ไปที่หน้า Settings
   - คลิก "ทดสอบการเชื่อมต่อ EasySlip API"

3. **ตรวจสอบ Request Headers:**
   - หา request ไปที่ `/functions/v1/verify-slip`
   - ตรวจสอบว่า `Authorization` header มีค่า
   - ตรวจสอบว่า `apikey` header มีค่า

---

## Checklist

### การตรวจสอบ:
- [ ] ตรวจสอบ Edge Function settings ใน Supabase Dashboard
- [ ] ตรวจสอบว่า "Require authentication" ปิดอยู่หรือไม่
- [ ] ลอง logout และ login ใหม่
- [ ] ตรวจสอบว่า session token ยังใช้งานได้
- [ ] ตรวจสอบว่า request headers ถูกส่งไปถูกต้อง

### การแก้ไข:
- [ ] ปิด "Require authentication" (ถ้ามี)
- [ ] Logout และ login ใหม่
- [ ] ลบ session token และ login ใหม่
- [ ] ทดสอบการเชื่อมต่ออีกครั้ง

---

## หมายเหตุ

⚠️ **สำคัญ:**
- HTTP 401 เกิดจาก Supabase reject request ก่อนถึง Edge Function code
- JWT token ดูถูกต้อง แต่ Supabase อาจ validate และ reject
- ต้องตรวจสอบ Edge Function settings และ session token

📝 **ขั้นตอนต่อไป:**
1. ตรวจสอบ Edge Function settings ใน Dashboard
2. ลอง logout และ login ใหม่
3. ทดสอบการเชื่อมต่ออีกครั้ง
4. ตรวจสอบ Logs ถ้ายังมีปัญหา
