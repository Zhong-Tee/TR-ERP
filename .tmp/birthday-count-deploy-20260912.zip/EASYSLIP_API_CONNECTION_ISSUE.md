# แก้ไขปัญหา EasySlip API ไม่สามารถเชื่อมต่อได้

## สถานะปัจจุบัน

✅ **ดีแล้ว:**
- Edge Function: เข้าถึงได้ ✅
- Secrets ตั้งค่าแล้ว: ตั้งค่าแล้ว ✅
  - `EASYSLIP_API_KEY` ✅
  - `SERVICE_ROLE_KEY` ✅
  - `PROJECT_URL` ✅
- Edge Function Deploy สำเร็จแล้ว ✅

❌ **ปัญหาที่พบ:**
- EasySlip API: ไม่สามารถเชื่อมต่อได้ ❌

---

## วิธีแก้ไข

### 1. ตรวจสอบ Logs ใน Supabase Dashboard

**ขั้นตอน:**

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ `zkzjbhvsltbwbtteihiy`

2. **ไปที่ Edge Functions → verify-slip → Logs:**
   - คลิกที่เมนู **Edge Functions** ด้านซ้าย
   - คลิกที่ function **verify-slip**
   - คลิกแท็บ **Logs**

3. **ดู Error Details:**
   - ดู logs ล่าสุด
   - หา error messages ที่เกี่ยวข้องกับ EasySlip API
   - ดู HTTP status code และ error message

**สิ่งที่ต้องดู:**
- HTTP status code (401, 403, 404, 500, etc.)
- Error message จาก EasySlip API
- Network errors

### 2. ตรวจสอบว่า EasySlip Service เปิดใช้งานแล้ว

**ขั้นตอน:**

1. **เข้า EasySlip Dashboard:**
   - ไปที่ https://developer.easyslip.com
   - Login เข้าสู่ระบบ

2. **ตรวจสอบสถานะ Service:**
   - ตรวจสอบว่า toggle switch "เปิดการใช้งาน" อยู่ในสถานะ ON
   - ถ้ายังปิดอยู่ ให้เปิดใช้งาน

3. **ตรวจสอบ Package/Plan:**
   - ตรวจสอบว่า Package/Plan ยังใช้งานได้
   - ตรวจสอบว่ามีการเติมเงินหรือต่ออายุแพ็กเกจหรือไม่

### 3. ตรวจสอบ EASYSLIP_API_KEY

**ขั้นตอน:**

1. **ตรวจสอบว่า API Key ถูกต้อง:**
   - ไปที่ EasySlip Dashboard → API หรือ API Keys
   - ตรวจสอบว่า API Key ที่ใช้ตรงกับที่ตั้งค่าใน Supabase หรือไม่
   - Copy API Key ใหม่ (ถ้าจำเป็น)

2. **อัปเดต API Key ใน Supabase:**
   - ไปที่ Supabase Dashboard → Settings → Edge Functions → Secrets
   - คลิกที่ `EASYSLIP_API_KEY` → Edit
   - ใส่ API Key ใหม่
   - คลิก Save

### 4. ทดสอบ API Key โดยตรง

**ใช้ curl หรือ Postman:**

```bash
# ทดสอบ EasySlip API
curl -X POST https://developer.easyslip.com/api/v1/verify \
  -H "Authorization: Bearer YOUR_EASYSLIP_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"image": "test"}'
```

**ตรวจสอบผลลัพธ์:**
- ถ้าได้ 401 → API Key ไม่ถูกต้อง
- ถ้าได้ 403 → ไม่มีสิทธิ์เข้าถึง หรือ Package หมดอายุ
- ถ้าได้ 404 → API endpoint ไม่ถูกต้อง
- ถ้าได้ 200 → API Key ถูกต้อง แต่มีปัญหาอื่น

---

## Checklist การแก้ไข

### การตรวจสอบ:
- [ ] ดู Logs ใน Supabase Dashboard → Edge Functions → verify-slip → Logs
- [ ] ตรวจสอบว่า EasySlip service เปิดใช้งานแล้ว
- [ ] ตรวจสอบว่า Package/Plan ยังใช้งานได้
- [ ] ตรวจสอบว่า EASYSLIP_API_KEY ถูกต้อง
- [ ] ทดสอบ API Key โดยตรง (ใช้ curl หรือ Postman)

### การแก้ไข:
- [ ] เปิดใช้งาน EasySlip service (ถ้ายังปิดอยู่)
- [ ] อัปเดต EASYSLIP_API_KEY (ถ้าไม่ถูกต้อง)
- [ ] ต่ออายุ Package/Plan (ถ้าหมดอายุ)
- [ ] Deploy Edge Function ใหม่ (ถ้าจำเป็น)

### การทดสอบ:
- [ ] ทดสอบการเชื่อมต่อจากหน้า Settings อีกครั้ง
- [ ] ตรวจสอบผลลัพธ์
- [ ] ทดสอบการตรวจสอบสลิปจริง

---

## Troubleshooting

### ปัญหา: HTTP 401 Unauthorized

**สาเหตุ:**
- API Key ไม่ถูกต้อง
- API Key หมดอายุ

**วิธีแก้:**
- ตรวจสอบ API Key ใน EasySlip Dashboard
- อัปเดต API Key ใน Supabase Secrets
- Deploy Edge Function ใหม่

### ปัญหา: HTTP 403 Forbidden

**สาเหตุ:**
- EasySlip service ยังไม่ได้เปิดใช้งาน
- Package/Plan หมดอายุ
- ไม่มีสิทธิ์เข้าถึง API

**วิธีแก้:**
- เปิดใช้งาน EasySlip service
- ตรวจสอบ Package/Plan
- ติดต่อ EasySlip Support

### ปัญหา: Network Error

**สาเหตุ:**
- EasySlip API endpoint ไม่สามารถเข้าถึงได้
- Network/Firewall บล็อค

**วิธีแก้:**
- ตรวจสอบว่า EasySlip API endpoint ถูกต้อง: `https://developer.easyslip.com/api/v1/verify`
- ตรวจสอบ Network/Firewall settings
- ลองอีกครั้งในภายหลัง

---

## หมายเหตุ

✅ **ดีแล้ว:**
- Edge Function และ Secrets ตั้งค่าถูกต้องแล้ว
- Deploy สำเร็จแล้ว

⚠️ **ปัญหาที่ต้องแก้:**
- EasySlip API ไม่สามารถเชื่อมต่อได้
- ต้องตรวจสอบ Logs เพื่อหาสาเหตุ

📝 **ขั้นตอนต่อไป:**
1. ดู Logs ใน Supabase Dashboard
2. ตรวจสอบว่า EasySlip service เปิดใช้งานแล้ว
3. ตรวจสอบว่า EASYSLIP_API_KEY ถูกต้อง
4. ทดสอบการเชื่อมต่ออีกครั้ง

---

## คำถามที่พบบ่อย

### Q: ทำไม Edge Function และ Secrets ตั้งค่าถูกต้องแล้ว แต่ EasySlip API ยังเชื่อมต่อไม่ได้?
**A:** อาจเป็นเพราะ:
- EasySlip service ยังไม่ได้เปิดใช้งาน
- EASYSLIP_API_KEY ไม่ถูกต้อง
- Package/Plan หมดอายุ
- Network issue

### Q: จะรู้ได้อย่างไรว่าปัญหาอยู่ที่ไหน?
**A:**
- ดู Logs ใน Supabase Dashboard → Edge Functions → verify-slip → Logs
- ทดสอบ API Key โดยตรง (ใช้ curl หรือ Postman)
- ตรวจสอบว่า EasySlip service เปิดใช้งานแล้ว

### Q: ถ้ายังแก้ไม่ได้ให้ทำอย่างไร?
**A:**
- ติดต่อ EasySlip Support: support@easyslip.com
- แจ้งปัญหาและ error messages จาก Logs
- แจ้งว่า Edge Function และ Secrets ตั้งค่าถูกต้องแล้ว
