# คู่มือเข้าถึง Supabase Dashboard

## สถานะปัจจุบัน

✅ **Dashboard เข้าได้แล้ว!**

- ✅ Login เข้า Supabase Dashboard ได้
- ⚠️ มี error เกี่ยวกับ organization `segargvekjxvtibkpiax` (ไม่มีอยู่หรือไม่มีสิทธิ์) - **ไม่เป็นปัญหา**
- ✅ Organization "TEE-ZHONG" ใช้งานได้ (Free Plan, 2 projects)

---

## ขั้นตอนการใช้งาน Dashboard

### 1. ปิด Error Message (ถ้ามี)

ถ้ามี error message "Organization not found" สำหรับ organization `segargvekjxvtibkpiax`:
- **ไม่เป็นปัญหา** - แค่เป็น organization ที่ไม่มีอยู่หรือไม่มีสิทธิ์เข้าถึง
- ปิด error message ได้โดยคลิกที่ปุ่ม "X" หรือปิด banner

### 2. เข้าไปที่ Organization "TEE-ZHONG"

1. **คลิกที่ organization "TEE-ZHONG"** ในรายการ
2. คุณจะเห็นรายการโปรเจกต์ทั้งหมดใน organization นี้

### 3. หาโปรเจกต์ที่ต้องการ

**ข้อมูลโปรเจกต์:**
- Project Reference: `zkzjbhvsltbwbtteihiy`
- SUPABASE_URL: `https://zkzjbhvsltbwbtteihiy.supabase.co`

**วิธีหา:**
- ดูในรายการโปรเจกต์ (ควรมี 2 projects)
- คลิกเข้าไปที่โปรเจกต์ที่ต้องการ

### 4. ตั้งค่า Edge Functions Secrets

เมื่อเข้าไปที่โปรเจกต์แล้ว:

1. **ไปที่ Settings:**
   - คลิกที่เมนู **Settings** ด้านซ้าย

2. **ไปที่ Edge Functions:**
   - คลิกที่ **Edge Functions** ในเมนู Settings
   - คลิกแท็บ **Secrets**

3. **เพิ่ม Secrets:**
   - คลิก **Add new secret**
   - เพิ่ม Secrets ทั้ง 3 ตัว:

   **a. EASYSLIP_API_KEY**
   - Name: `EASYSLIP_API_KEY`
   - Value: `<your-easyslip-api-key>` (ต้องหา API Key ก่อน)

   **b. SERVICE_ROLE_KEY**
   - Name: `SERVICE_ROLE_KEY`
   - Value: `<your-service-role-key>` (หาได้จาก Email หรือ Settings → API)

   **c. PROJECT_URL**
   - Name: `PROJECT_URL` (ใช้ชื่อนี้แทน SUPABASE_URL เพื่อหลีกเลี่ยง reserved prefix)
   - Value: `https://zkzjbhvsltbwbtteihiy.supabase.co`

### 5. Deploy Edge Function

1. **ไปที่ Edge Functions:**
   - คลิกที่เมนู **Edge Functions** ด้านซ้าย

2. **หา function "verify-slip":**
   - ดูในรายการ functions
   - ถ้ายังไม่มี ให้ Deploy ใหม่

3. **Deploy Function:**
   - คลิกที่ function "verify-slip"
   - คลิก **Deploy** หรือ **Update**

---

## วิธีหา SERVICE_ROLE_KEY

### จาก Dashboard:

1. **ไปที่ Settings → API:**
   - คลิกที่เมนู **Settings** ด้านซ้าย
   - คลิกที่ **API**

2. **หา Service Role Key:**
   - ดูในส่วน "Project API keys"
   - หา "service_role" key
   - คลิกที่ปุ่ม "Reveal" หรือ "Show" เพื่อดูค่า
   - ⚠️ **ระวัง: อย่าเปิดเผย key นี้**

### จาก Email:

- ตรวจสอบ Email ที่ได้รับตอนสร้างโปรเจกต์ Supabase
- Email นั้นจะมี API keys รวมถึง service_role key

---

## วิธีหา EASYSLIP_API_KEY

### ทางเลือกที่ 1: จาก EasySlip Dashboard

1. **เข้า EasySlip Dashboard:**
   - ไปที่ https://developer.easyslip.com
   - Login เข้าสู่ระบบ (ถ้าเข้าได้)

2. **หา API Key:**
   - ไปที่เมนู "API" หรือ "API Keys"
   - Copy API Key

### ทางเลือกที่ 2: จากที่เก็บไว้

- ตรวจสอบไฟล์ notes หรือ password manager
- ตรวจสอบ email ที่ได้รับตอนสมัคร EasySlip
- ตรวจสอบไฟล์ config เก่า

### ทางเลือกที่ 3: ติดต่อ EasySlip Support

- ส่ง email ไปที่ support@easyslip.com
- ขอ API Key ใหม่

---

## Checklist

### การเข้าถึง Dashboard:
- [x] Login เข้า Supabase Dashboard ได้
- [ ] ปิด error message (ถ้ามี)
- [ ] เข้าไปที่ organization "TEE-ZHONG"
- [ ] หาโปรเจกต์ `zkzjbhvsltbwbtteihiy`
- [ ] เข้าไปที่โปรเจกต์

### การตั้งค่า Secrets:
- [ ] หา SERVICE_ROLE_KEY (จาก Dashboard หรือ Email)
- [ ] หา EASYSLIP_API_KEY (จาก EasySlip หรือที่เก็บไว้)
- [ ] ตั้งค่า `EASYSLIP_API_KEY` ใน Dashboard
- [ ] ตั้งค่า `SERVICE_ROLE_KEY` ใน Dashboard
- [ ] ตั้งค่า `PROJECT_URL` ใน Dashboard (แทน SUPABASE_URL)

### การ Deploy Edge Function:
- [ ] ไปที่ Edge Functions
- [ ] ตรวจสอบว่า function "verify-slip" มีอยู่
- [ ] Deploy หรือ Update function
- [ ] ตรวจสอบ Logs ไม่มี errors

---

## Troubleshooting

### ปัญหา: ไม่เห็นโปรเจกต์ `zkzjbhvsltbwbtteihiy`

**วิธีแก้:**
- ตรวจสอบว่าโปรเจกต์อยู่ใน organization "TEE-ZHONG" หรือไม่
- ลองค้นหาโปรเจกต์ด้วยชื่อหรือ reference ID
- ตรวจสอบว่า Account ของคุณมีสิทธิ์เข้าถึงโปรเจกต์

### ปัญหา: ไม่เห็น Edge Functions

**วิธีแก้:**
- ตรวจสอบว่า Deploy Edge Function แล้วหรือยัง
- ลองใช้ Supabase CLI เพื่อ Deploy:
  ```powershell
  cd e:\Web_App\TR-ERP
  supabase functions deploy verify-slip
  ```

### ปัญหา: ไม่สามารถตั้งค่า Secrets ได้

**วิธีแก้:**
- ตรวจสอบว่า Account ของคุณมีสิทธิ์ "Owner" หรือ "Admin"
- ลองใช้ Supabase CLI แทน:
  ```powershell
  supabase secrets set EASYSLIP_API_KEY=your-api-key
  supabase secrets set SERVICE_ROLE_KEY=your-service-role-key
  supabase secrets set SUPABASE_URL=https://zkzjbhvsltbwbtteihiy.supabase.co
  ```

---

## หมายเหตุ

✅ **ดีแล้ว:**
- Dashboard เข้าได้แล้ว
- Organization "TEE-ZHONG" ใช้งานได้
- สามารถตั้งค่า Secrets และ Deploy Edge Function ได้

⚠️ **สิ่งที่ต้องทำ:**
- หา SERVICE_ROLE_KEY และ EASYSLIP_API_KEY
- ตั้งค่า Secrets ทั้ง 3 ตัว
- Deploy Edge Function
- ทดสอบระบบ

📝 **ขั้นตอนต่อไป:**
1. เข้าไปที่ organization "TEE-ZHONG"
2. หาโปรเจกต์ `zkzjbhvsltbwbtteihiy`
3. ตั้งค่า Secrets
4. Deploy Edge Function
5. ทดสอบระบบ
