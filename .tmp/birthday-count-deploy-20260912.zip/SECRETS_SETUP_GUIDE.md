# คู่มือตั้งค่า Secrets สำหรับ Edge Functions

## ปัญหาที่พบ

เมื่อพยายามตั้งค่า `SUPABASE_URL` เป็น secret:
```
Env name cannot start with SUPABASE_, skipping: SUPABASE_URL
```

**สาเหตุ:** Supabase CLI ไม่ให้ตั้งค่า secret ที่ชื่อขึ้นต้นด้วย `SUPABASE_` เพราะเป็น reserved prefix

---

## วิธีแก้ไข

### ✅ ไม่ต้องตั้งค่า `SUPABASE_URL` เป็น Secret

**เหตุผล:**
- Supabase Edge Functions มี `SUPABASE_URL` ให้อัตโนมัติอยู่แล้ว
- Edge Function สามารถอ่านได้จาก environment variables ที่ Supabase จัดให้

### ✅ ตั้งค่า Secrets ที่จำเป็นเท่านั้น

**ต้องตั้งค่า Secrets 3 ตัว:**

1. **EASYSLIP_API_KEY**
2. **SERVICE_ROLE_KEY**
3. **PROJECT_URL** (แทน SUPABASE_URL เพื่อหลีกเลี่ยง reserved prefix)

---

## ขั้นตอนการตั้งค่า Secrets

### วิธีที่ 1: ใช้ Supabase CLI (แนะนำ)

```powershell
# ไปที่โฟลเดอร์โปรเจกต์
cd e:\Web_App\TR-ERP

# ตั้งค่า EASYSLIP_API_KEY
supabase secrets set EASYSLIP_API_KEY=your-easyslip-api-key-here

# ตั้งค่า SERVICE_ROLE_KEY
supabase secrets set SERVICE_ROLE_KEY=your-service-role-key-here

# ตั้งค่า PROJECT_URL (แทน SUPABASE_URL เพื่อหลีกเลี่ยง reserved prefix)
supabase secrets set PROJECT_URL=https://zkzjbhvsltbwbtteihiy.supabase.co
```

**หมายเหตุ:** ไม่ต้องตั้งค่า `SUPABASE_URL` เพราะ Supabase จัดให้อัตโนมัติ

### วิธีที่ 2: ใช้ Dashboard

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ `zkzjbhvsltbwbtteihiy`

2. **ไปที่ Settings → Edge Functions → Secrets:**
   - คลิกที่เมนู **Settings** ด้านซ้าย
   - คลิกที่ **Edge Functions**
   - คลิกแท็บ **Secrets**

3. **เพิ่ม Secrets:**
   - คลิก **Add new secret**
   - เพิ่ม Secrets ทั้ง 2 ตัว:

   **a. EASYSLIP_API_KEY**
   - Name: `EASYSLIP_API_KEY`
   - Value: `<your-easyslip-api-key>`

   **b. SERVICE_ROLE_KEY**
   - Name: `SERVICE_ROLE_KEY`
   - Value: `<your-service-role-key>` (หาได้จาก Settings → API)

---

## วิธีหา SERVICE_ROLE_KEY

### จาก Dashboard:

1. **ไปที่ Settings → API:**
   - คลิกที่เมนู **Settings** ด้านซ้าย
   - คลิกที่ **API**

2. **หา Service Role Key:**
   - ดูในส่วน "Project API keys"
   - หา "service_role" key
   - คลิกที่ปุ่ม "Reveal" หรือ "Show" เพื่อดูค่า
   - ⚠️ **ระวัง: อย่าเปิดเผย key นี้**

### จาก Email:

- ตรวจสอบ Email ที่ได้รับตอนสร้างโปรเจกต์ Supabase
- Email นั้นจะมี API keys รวมถึง service_role key

---

## ตรวจสอบ Secrets

### ใช้ CLI:

```powershell
# ดู secrets ที่ตั้งค่าไว้
supabase secrets list
```

### ใช้ Dashboard:

- ไปที่ Settings → Edge Functions → Secrets
- ดูรายการ secrets ที่ตั้งค่าไว้

---

## Checklist

### การตั้งค่า Secrets:
- [ ] หา SERVICE_ROLE_KEY (จาก Dashboard → Settings → API)
- [ ] หา EASYSLIP_API_KEY (จาก EasySlip หรือที่เก็บไว้)
- [ ] ตั้งค่า `EASYSLIP_API_KEY` (ใช้ CLI หรือ Dashboard)
- [ ] ตั้งค่า `SERVICE_ROLE_KEY` (ใช้ CLI หรือ Dashboard)
- [ ] ตั้งค่า `PROJECT_URL` (ใช้ CLI หรือ Dashboard) - แทน SUPABASE_URL เพื่อหลีกเลี่ยง reserved prefix
- [ ] ตรวจสอบ Secrets (`supabase secrets list`)

---

## หมายเหตุ

✅ **ดีแล้ว:**
- Edge Function `verify-slip` Deploy สำเร็จแล้ว
- โค้ดได้รับการอัปเดตให้ใช้ `SUPABASE_URL` จาก environment variables อัตโนมัติ

⚠️ **สิ่งที่ต้องทำ:**
- ตั้งค่า `EASYSLIP_API_KEY`, `SERVICE_ROLE_KEY`, และ `PROJECT_URL`
- ใช้ `PROJECT_URL` แทน `SUPABASE_URL` เพื่อหลีกเลี่ยง reserved prefix

📝 **ขั้นตอนต่อไป:**
1. ตั้งค่า `EASYSLIP_API_KEY` และ `SERVICE_ROLE_KEY`
2. ตรวจสอบ Secrets
3. ทดสอบ Edge Function

---

## คำถามที่พบบ่อย

### Q: ทำไมต้องใช้ `PROJECT_URL` แทน `SUPABASE_URL`?
**A:** เพราะ Supabase CLI ไม่ให้ตั้งค่า secret ที่ชื่อขึ้นต้นด้วย `SUPABASE_` (reserved prefix) ดังนั้นเราใช้ `PROJECT_URL` แทน แต่ Edge Function ยังรองรับ `SUPABASE_URL` จาก environment variables อัตโนมัติเป็น fallback

### Q: ถ้าต้องการใช้ `SUPABASE_URL` ที่แตกต่างจากค่า default ล่ะ?
**A:** สามารถแก้ไขโค้ด Edge Function ให้ใช้ค่าจาก request context หรือ hardcode ค่าได้ (แต่ไม่แนะนำ)

### Q: จะรู้ได้อย่างไรว่า Secrets ตั้งค่าถูกต้อง?
**A:** 
- ตรวจสอบด้วย `supabase secrets list`
- ทดสอบ Edge Function โดยอัปโหลดสลิป
- ดู Logs ใน Dashboard
