ALTER TABLE or_orders
ADD COLUMN IF NOT EXISTS confirm_note TEXT;
