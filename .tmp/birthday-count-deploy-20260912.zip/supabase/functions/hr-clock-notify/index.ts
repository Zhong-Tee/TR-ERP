// แจ้งเตือนเข้างาน/ออกงานเข้ากลุ่ม Manager (Telegram) พร้อมรูปถ่ายจากการบันทึกเวลา
// เรียกจาก client หลังบันทึก hr_time_entries สำเร็จ: body = { entry_id }
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const ENTRY_LABELS: Record<string, { emoji: string; label: string }> = {
  clock_in: { emoji: '📥', label: 'เข้างาน' },
  clock_out: { emoji: '📤', label: 'ออกงาน' },
  ot_in: { emoji: '⏱️', label: 'เข้า OT' },
  ot_out: { emoji: '⏱️', label: 'ออก OT' },
}

function escapeHtml(value: unknown): string {
  return String(value ?? '-')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
}

function toMinutes(t: string): number {
  const [h, m] = t.split(':').map(Number)
  return h * 60 + (m || 0)
}

/** ระยะเวลาเป็นนาที → hh:mm ชม. */
function minutesToHHMM(min: number): string {
  const h = Math.floor(min / 60)
  const m = min % 60
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')} ชม.`
}

/** HH:MM (นาที) ของ timestamp ตามเวลาไทย */
function bangkokMinutes(iso: string): number {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Bangkok',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(new Date(iso))
  const h = Number(parts.find((p) => p.type === 'hour')?.value ?? 0)
  const m = Number(parts.find((p) => p.type === 'minute')?.value ?? 0)
  return h * 60 + m
}

function bangkokTimeText(iso: string): string {
  return new Date(iso).toLocaleTimeString('th-TH', {
    timeZone: 'Asia/Bangkok',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })
}

function bangkokDateText(iso: string): string {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(new Date(iso))
  const year = parts.find((p) => p.type === 'year')?.value ?? ''
  const month = parts.find((p) => p.type === 'month')?.value ?? ''
  const day = parts.find((p) => p.type === 'day')?.value ?? ''
  return `${year}-${month}-${day}`
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { entry_id } = await req.json()
    if (!entry_id) throw new Error('entry_id required')

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )

    const { data: settings } = await supabase
      .from('hr_notification_settings')
      .select('bot_token, manager_group_chat_id')
      .limit(1)
      .single()

    if (!settings?.bot_token || !settings.manager_group_chat_id) {
      return new Response(JSON.stringify({ skipped: 'no bot token or manager group configured' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const { data: entry, error: entryError } = await supabase
      .from('hr_time_entries')
      .select('*, employee:hr_employees!employee_id(first_name, last_name, nickname, work_schedule_id, work_mode, position:hr_positions!position_id(name))')
      .eq('id', entry_id)
      .single()
    if (entryError || !entry) throw new Error('entry not found: ' + entryError?.message)

    const emp = entry.employee
    const name = `${emp?.first_name ?? ''} ${emp?.last_name ?? ''}`.trim() || '-'
    const nickname = emp?.nickname ?? '-'
    const position = emp?.position?.name ?? '-'
    const typeInfo = ENTRY_LABELS[entry.entry_type] ?? { emoji: '🕐', label: entry.entry_type }

    // คำนวณมาสาย/ออกก่อน ตามมาตรฐานเวลาของพนักงาน
    let timingAlertText = ''
    let graceText = ''
    if (emp?.work_mode !== 'no_clock' && (entry.entry_type === 'clock_in' || entry.entry_type === 'clock_out')) {
      let sched: { work_start: string; work_end: string; late_grace_min: number } | null = null
      if (emp?.work_schedule_id) {
        const { data } = await supabase
          .from('hr_work_schedules')
          .select('work_start, work_end, late_grace_min, is_active')
          .eq('id', emp.work_schedule_id)
          .single()
        if (data?.is_active) sched = data
      }
      if (!sched) {
        const { data } = await supabase
          .from('hr_work_schedules')
          .select('work_start, work_end, late_grace_min')
          .eq('is_default', true)
          .eq('is_active', true)
          .limit(1)
          .maybeSingle()
        sched = data
      }
      if (sched) {
        // An approved WFH request may define a different working time range.
        // Use that range for Telegram timing alerts, consistent with
        // hr_attendance_facts. Older WFH requests without a range continue to
        // use the employee's normal schedule.
        let effectiveWorkStart = sched.work_start
        let effectiveWorkEnd = sched.work_end
        if (entry.work_location_type === 'wfh_approved') {
          const workDate = entry.work_date || bangkokDateText(entry.entry_time)
          let wfhQuery = supabase
            .from('hr_wfh_requests')
            .select('id, start_time, end_time')
            .eq('employee_id', entry.employee_id)
            .eq('status', 'approved')

          if (entry.wfh_request_id) {
            wfhQuery = wfhQuery.eq('id', entry.wfh_request_id)
          } else {
            wfhQuery = wfhQuery.lte('start_date', workDate).gte('end_date', workDate)
          }

          const { data: approvedWfh } = await wfhQuery
            .order('approved_at', { ascending: false })
            .limit(1)
            .maybeSingle()

          if (approvedWfh?.start_time && approvedWfh?.end_time) {
            effectiveWorkStart = approvedWfh.start_time
            effectiveWorkEnd = approvedWfh.end_time
          }
        }

        if (entry.entry_type === 'clock_in') {
          const grace = sched.late_grace_min ?? 0
          const lateBeyond = bangkokMinutes(entry.entry_time) - (toMinutes(effectiveWorkStart) + grace)
          if (lateBeyond > 0) {
            const workDate = bangkokDateText(entry.entry_time)
            const expectedStart = toMinutes(effectiveWorkStart)
            const { data: hourlyLeaves } = await supabase.from('hr_leave_requests')
              .select('start_time, end_time, leave_type:hr_leave_types(name)')
              .eq('employee_id', entry.employee_id)
              .eq('status', 'approved')
              .eq('leave_mode', 'hourly')
              .lte('start_date', workDate)
              .gte('end_date', workDate)
            const coveredLeave = (hourlyLeaves ?? []).find((leave) => {
              if (!leave.start_time || !leave.end_time) return false
              return toMinutes(leave.start_time) <= expectedStart && expectedStart <= toMinutes(leave.end_time)
            })
            if (coveredLeave) {
              const leaveType = Array.isArray(coveredLeave.leave_type)
                ? coveredLeave.leave_type[0]?.name
                : (coveredLeave.leave_type as { name?: string } | null)?.name
              timingAlertText = `✅ <b>มีใบลารายชั่วโมงที่อนุมัติแล้ว:</b> ${escapeHtml(leaveType ?? 'ลา')} ${escapeHtml(String(coveredLeave.start_time).slice(0, 5))}–${escapeHtml(String(coveredLeave.end_time).slice(0, 5))} น.`
            } else {
              timingAlertText = `⚠️ <b>มาสาย:</b> ${minutesToHHMM(lateBeyond)}`
              if (grace > 0) graceText = `ℹ️ (เกินผ่อนผัน ${grace} นาที)`
            }
          }
        } else {
          const earlyBy = toMinutes(effectiveWorkEnd) - bangkokMinutes(entry.entry_time)
          if (earlyBy > 0) {
            timingAlertText = `⚠️ <b>ออกก่อน:</b> ${minutesToHHMM(earlyBy)}`
          }
        }
      }
    }

    const distance = entry.distance_m != null ? ` (ห่าง ${Math.round(entry.distance_m)} ม.)` : ''
    const captionLines = [
      `${typeInfo.emoji} <b>${typeInfo.label}</b>`,
      `👤 <b>ชื่อ:</b> ${escapeHtml(name)}`,
      `🏷️ <b>ชื่อเล่น:</b> ${escapeHtml(nickname)}`,
      `💼 <b>ตำแหน่ง:</b> ${escapeHtml(position)}`,
      `🕐 <b>เวลา:</b> ${escapeHtml(bangkokTimeText(entry.entry_time))} น.`,
      `📍 <b>สถานที่:</b> ${escapeHtml(entry.location_name ?? '-')}${escapeHtml(distance)}`,
    ]
    if (timingAlertText) captionLines.push(timingAlertText)
    if (graceText) captionLines.push(graceText)
    const caption = captionLines.join('\n')

    // รูปถ่ายอยู่ใน bucket private → สร้าง signed URL ให้ Telegram ดึง
    let photoUrl: string | null = null
    if (entry.photo_url) {
      const { data } = await supabase.storage.from('hr-time-clock').createSignedUrl(entry.photo_url, 600)
      photoUrl = data?.signedUrl ?? null
    }

    const botBase = `https://api.telegram.org/bot${settings.bot_token}`
    let res: Response
    if (photoUrl) {
      res = await fetch(`${botBase}/sendPhoto`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: settings.manager_group_chat_id,
          photo: photoUrl,
          caption,
          parse_mode: 'HTML',
        }),
      })
    } else {
      res = await fetch(`${botBase}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: settings.manager_group_chat_id,
          text: caption,
          parse_mode: 'HTML',
        }),
      })
    }

    const ok = res.ok
    const resText = ok ? 'sent' : await res.text()

    await supabase.from('hr_notification_logs').insert({
      type: `clock_${entry.entry_type}`,
      target_chat_id: settings.manager_group_chat_id,
      message: ok ? caption : resText,
      status: ok ? 'sent' : 'failed',
      related_id: entry_id,
    })

    return new Response(JSON.stringify({ success: ok, detail: resText }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
