# แก้ไขปัญหา EasySlip ถูกบล็อค

## สาเหตุที่เป็นไปได้

1. **IP Address ถูกบล็อค** - จากการพยายามเข้าหลายครั้ง
2. **Account ถูกระงับ** - จากการใช้งานผิดปกติ
3. **Browser/Cookie Issues** - Cache หรือ cookies มีปัญหา
4. **Network/Firewall** - Firewall หรือ network settings บล็อค
5. **Account Status** - บัญชีถูกระงับหรือมีปัญหา

---

## วิธีแก้ไข (ลองตามลำดับ)

### วิธีที่ 1: ล้าง Cache และ Cookies

1. **Chrome/Edge:**
   - กด `Ctrl + Shift + Delete`
   - เลือก "Cookies and other site data" และ "Cached images and files"
   - เลือก "All time"
   - คลิก "Clear data"

2. **Firefox:**
   - กด `Ctrl + Shift + Delete`
   - เลือก "Cookies" และ "Cache"
   - เลือก "Everything"
   - คลิก "Clear Now"

3. **ลองใช้ Incognito/Private Mode:**
   - Chrome: `Ctrl + Shift + N`
   - Firefox: `Ctrl + Shift + P`
   - Edge: `Ctrl + Shift + N`

### วิธีที่ 2: เปลี่ยน Network

1. **ลองใช้ Network อื่น:**
   - ใช้ Mobile Hotspot
   - ใช้ VPN (ถ้ามี)
   - ใช้ Network อื่น

2. **ลองใช้ Device อื่น:**
   - ใช้คอมพิวเตอร์เครื่องอื่น
   - ใช้มือถือ/แท็บเล็ต

### วิธีที่ 3: ตรวจสอบ Account Status

1. **ลอง Reset Password:**
   - ไปที่หน้า Login
   - คลิก "Forgot Password"
   - Reset password และลอง login ใหม่

2. **ติดต่อ EasySlip Support:**
   - Email: support@easyslip.com (ตรวจสอบจากเว็บไซต์)
   - อธิบายปัญหาที่พบ
   - แจ้งว่าไม่สามารถเข้าถึง Dashboard ได้

### วิธีที่ 4: ใช้ API Key ที่มีอยู่แล้ว

**ถ้าคุณมี API Key อยู่แล้ว** คุณสามารถใช้ได้โดยไม่ต้องเข้า Dashboard:

1. **หา API Key จากที่เก็บไว้:**
   - ตรวจสอบไฟล์ notes หรือ password manager
   - ตรวจสอบ email ที่ได้รับตอนสมัคร

2. **ตั้งค่าใน Supabase โดยตรง:**
   - ไปที่ Supabase Dashboard → Settings → Edge Functions → Secrets
   - เพิ่ม Secret: `EASYSLIP_API_KEY` = `<your-existing-api-key>`

3. **ทดสอบ API Key:**
   ```bash
   # ทดสอบ API Key (ใช้ curl หรือ Postman)
   curl -X POST https://developer.easyslip.com/api/v1/verify \
     -H "Authorization: Bearer YOUR_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"image": "base64-encoded-image"}'
   ```

---

## วิธีติดต่อ EasySlip Support

### ข้อมูลที่ควรแจ้ง:
1. **Email ที่ใช้สมัคร**
2. **ปัญหาที่พบ:** "ไม่สามารถเข้าถึง Dashboard ได้, ถูกบล็อค"
3. **สิ่งที่ลองทำแล้ว:** ล้าง cache, เปลี่ยน network, etc.
4. **Screenshot:** ถ้ามี error message

### ช่องทางติดต่อ:
- **Email:** support@easyslip.com (ตรวจสอบจากเว็บไซต์)
- **Website:** https://easyslip.com (หาหน้า Contact/Support)
- **Line:** ถ้ามี (ตรวจสอบจากเว็บไซต์)

---

## ทางเลือกชั่วคราว

### ถ้ายังไม่สามารถเข้า EasySlip ได้:

1. **ใช้ API Key ที่มีอยู่แล้ว:**
   - ถ้ามี API Key เก่า ใช้ได้เลย
   - ตั้งค่าใน Supabase Secrets

2. **รอ EasySlip Support ตอบกลับ:**
   - ในระหว่างนี้ ระบบจะยังไม่สามารถตรวจสอบสลิปได้
   - แต่ยังสามารถบันทึกออเดอร์และอัปโหลดสลิปได้

3. **ทดสอบระบบอื่นๆ:**
   - ตรวจสอบว่า Supabase Edge Functions ตั้งค่าถูกต้อง
   - ตรวจสอบว่า Storage bucket ทำงานได้
   - ตรวจสอบว่า Frontend ทำงานได้

---

## Checklist สำหรับตอนนี้

### สิ่งที่ทำได้ทันที:
- [ ] ลองล้าง cache และ cookies
- [ ] ลองใช้ Incognito/Private mode
- [ ] ลองใช้ network อื่น
- [ ] ลองใช้ device อื่น
- [ ] ตรวจสอบว่ามี API Key เก่าหรือไม่

### สิ่งที่ต้องทำ:
- [ ] ติดต่อ EasySlip Support
- [ ] ตั้งค่า Supabase Secrets (ถ้ามี API Key)
- [ ] Deploy Edge Function
- [ ] ทดสอบระบบ

---

## หมายเหตุ

⚠️ **สำคัญ:**
- ระบบตรวจสอบสลิปจะไม่ทำงานจนกว่าจะมี API Key ที่ใช้งานได้
- แต่ระบบอื่นๆ (บันทึกออเดอร์, อัปโหลดสลิป) ยังทำงานได้ปกติ
- สลิปที่อัปโหลดจะถูกเก็บไว้ใน Storage และสามารถตรวจสอบได้ภายหลังเมื่อมี API Key

📝 **ขั้นตอนต่อไป:**
1. ลองวิธีแก้ไขตามลำดับ
2. ติดต่อ EasySlip Support
3. ตั้งค่า Supabase Secrets เมื่อมี API Key
4. Deploy และทดสอบ Edge Function
