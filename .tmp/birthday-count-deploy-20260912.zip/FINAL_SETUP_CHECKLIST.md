# Checklist สุดท้าย: ตรวจสอบและทดสอบระบบ

## ✅ สถานะปัจจุบัน

- [x] Supabase Dashboard เข้าได้แล้ว
- [x] Edge Function `verify-slip` Deploy สำเร็จแล้ว
- [x] `EASYSLIP_API_KEY` ตั้งค่าแล้ว
- [x] `SERVICE_ROLE_KEY` ตั้งค่าแล้ว
- [x] `SUPABASE_URL` ไม่ต้องตั้ง (Supabase จัดให้อัตโนมัติ)

---

## ขั้นตอนสุดท้าย: ตรวจสอบและทดสอบ

### 1. ตรวจสอบ Secrets ที่ตั้งค่าไว้

```powershell
# ดู secrets ทั้งหมด
supabase secrets list
```

**ควรเห็น:**
- `EASYSLIP_API_KEY` ✅
- `SERVICE_ROLE_KEY` ✅

### 2. Deploy Edge Function ใหม่ (ถ้ายังไม่ได้ Deploy หลังตั้งค่า Secrets)

```powershell
cd e:\Web_App\TR-ERP
supabase functions deploy verify-slip
```

**หมายเหตุ:** ถ้า Deploy ไปแล้วก่อนตั้งค่า Secrets อาจต้อง Deploy ใหม่เพื่อให้ function ใช้ Secrets ที่ตั้งค่าไว้

### 3. ตรวจสอบ Edge Function ใน Dashboard

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard/project/zkzjbhvsltbwbtteihiy/functions

2. **ตรวจสอบ function `verify-slip`:**
   - ดูว่า function อยู่ในสถานะ "Active"
   - ตรวจสอบ URL: `https://zkzjbhvsltbwbtteihiy.supabase.co/functions/v1/verify-slip`

### 4. ทดสอบ Edge Function

**วิธีที่ 1: ทดสอบจากแอปพลิเคชัน**

1. **เปิดแอปพลิเคชัน:**
   - รันแอปพลิเคชัน (ถ้ายังไม่ได้รัน)

2. **ทดสอบอัปโหลดสลิป:**
   - ไปที่หน้า Order Form
   - อัปโหลดสลิป
   - กดปุ่ม "บันทึก (ข้อมูลครบ)" เพื่อตรวจสอบสลิป
   - ตรวจสอบว่าการตรวจสอบสลิปทำงานได้

**วิธีที่ 2: ทดสอบด้วย Script**

```powershell
# ใช้ test script ที่มีอยู่
node test-verify-slip.js
```

### 5. ตรวจสอบ Logs

1. **ดู Logs ใน Dashboard:**
   - ไปที่ Edge Functions → verify-slip → Logs
   - ตรวจสอบว่าไม่มี errors
   - ดู logs ว่ามีการเรียกใช้ function หรือไม่

2. **ดู Logs ด้วย CLI:**
   ```powershell
   supabase functions logs verify-slip
   ```

---

## Checklist สุดท้าย

### การตั้งค่า:
- [x] Edge Function `verify-slip` Deploy สำเร็จ
- [x] `EASYSLIP_API_KEY` ตั้งค่าแล้ว
- [x] `SERVICE_ROLE_KEY` ตั้งค่าแล้ว
- [ ] ตรวจสอบ Secrets (`supabase secrets list`)
- [ ] Deploy function ใหม่ (ถ้าจำเป็น)

### การทดสอบ:
- [ ] ตรวจสอบ Edge Function ใน Dashboard
- [ ] ทดสอบอัปโหลดสลิปจากแอปพลิเคชัน
- [ ] ทดสอบการตรวจสอบสลิป
- [ ] ตรวจสอบ Logs ไม่มี errors

### การตรวจสอบผลลัพธ์:
- [ ] สลิปอัปโหลดได้
- [ ] การตรวจสอบสลิปทำงานได้
- [ ] ผลการตรวจสอบถูกบันทึกลงฐานข้อมูล
- [ ] สถานะบิลอัปเดตถูกต้อง

---

## Troubleshooting

### ปัญหา: Edge Function ไม่ทำงาน

**ตรวจสอบ:**
1. Secrets ตั้งค่าถูกต้องหรือไม่ (`supabase secrets list`)
2. Function Deploy สำเร็จหรือไม่
3. Logs มี errors หรือไม่

**วิธีแก้:**
- ตรวจสอบ Secrets อีกครั้ง
- Deploy function ใหม่
- ดู Logs เพื่อหาสาเหตุ

### ปัญหา: HTTP 401 Unauthorized

**ตรวจสอบ:**
1. `SERVICE_ROLE_KEY` ถูกต้องหรือไม่
2. Session token หมดอายุหรือไม่

**วิธีแก้:**
- ตรวจสอบ `SERVICE_ROLE_KEY` อีกครั้ง
- ลอง logout และ login ใหม่ในแอป

### ปัญหา: EasySlip API ไม่ทำงาน

**ตรวจสอบ:**
1. `EASYSLIP_API_KEY` ถูกต้องหรือไม่
2. EasySlip service เปิดใช้งานหรือไม่

**วิธีแก้:**
- ตรวจสอบ `EASYSLIP_API_KEY` อีกครั้ง
- ตรวจสอบว่า EasySlip service เปิดใช้งานแล้ว

---

## หมายเหตุ

✅ **สำเร็จแล้ว:**
- ตั้งค่า Secrets ทั้งหมดเสร็จแล้ว
- Edge Function Deploy สำเร็จแล้ว

📝 **ขั้นตอนต่อไป:**
1. ตรวจสอบ Secrets
2. ทดสอบระบบ
3. ตรวจสอบ Logs
4. แก้ไขปัญหาที่พบ (ถ้ามี)

---

## คำถามที่พบบ่อย

### Q: ต้อง Deploy function ใหม่หลังจากตั้งค่า Secrets หรือไม่?
**A:** 
- ถ้า Deploy ไปแล้วก่อนตั้งค่า Secrets อาจต้อง Deploy ใหม่
- แต่โดยปกติ Supabase จะใช้ Secrets ที่ตั้งค่าไว้ทันที

### Q: จะรู้ได้อย่างไรว่าระบบทำงานได้?
**A:**
- ทดสอบอัปโหลดสลิปและตรวจสอบ
- ดู Logs ว่าไม่มี errors
- ตรวจสอบว่าผลการตรวจสอบถูกบันทึกลงฐานข้อมูล

### Q: ถ้ามีปัญหาให้ทำอย่างไร?
**A:**
- ดู Logs ใน Dashboard
- ตรวจสอบ Secrets อีกครั้ง
- ตรวจสอบว่า EasySlip service เปิดใช้งานแล้ว
