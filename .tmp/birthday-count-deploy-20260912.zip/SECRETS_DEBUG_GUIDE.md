# Debug: ทำไม Secrets ยังไม่ได้ตั้งค่า?

## สถานะปัจจุบัน

จากผลการทดสอบ:
- ✅ Edge Function: เข้าถึงได้
- ❌ Secrets ตั้งค่าแล้ว: ยังไม่ได้ตั้งค่า
- ❌ EasySlip API: ไม่สามารถเชื่อมต่อได้

แต่จาก `supabase secrets list` แสดงว่า secrets ตั้งค่าแล้ว

---

## สาเหตุที่เป็นไปได้

### 1. Edge Function ไม่ได้อ่าน secrets ได้

**ตรวจสอบ:**
1. ไปที่ Supabase Dashboard → Edge Functions → verify-slip → Logs
2. ดู logs ล่าสุดหลังจากทดสอบการเชื่อมต่อ
3. หา logs ที่มี:
   - `[Edge Function] EASYSLIP_API_KEY present: true/false`
   - `[Edge Function] SERVICE_ROLE_KEY present: true/false`

**ถ้าแสดง `false`:**
- Secrets ไม่ได้ถูกอ่านใน Edge Function
- อาจต้อง deploy Edge Function ใหม่หลังตั้งค่า secrets

### 2. Secrets ตั้งค่าในโปรเจกต์ผิด

**ตรวจสอบ:**
```powershell
supabase secrets list
```

**ถ้าไม่เห็น secrets:**
- Secrets ไม่ได้ตั้งค่าในโปรเจกต์ที่ถูกต้อง
- ต้องตั้งค่าใหม่

### 3. Edge Function ต้อง restart หลังตั้งค่า secrets

**แก้ไข:**
```powershell
# Deploy Edge Function ใหม่ (เพื่อให้ secrets มีผล)
supabase functions deploy verify-slip
```

---

## วิธีแก้ไข

### วิธีที่ 1: ตรวจสอบ Logs

1. **ทดสอบการเชื่อมต่อ:**
   - ไปที่หน้า Settings
   - คลิก "ทดสอบการเชื่อมต่อ EasySlip API"

2. **ดู Logs ทันที:**
   - ไปที่ Supabase Dashboard → Edge Functions → verify-slip → Logs
   - ดู logs ล่าสุด
   - หา logs ที่มี `EASYSLIP_API_KEY present` และ `SERVICE_ROLE_KEY present`

3. **ตรวจสอบผลลัพธ์:**
   - ถ้าแสดง `true` → Secrets ถูกอ่านได้ แต่มีปัญหาอื่น
   - ถ้าแสดง `false` → Secrets ไม่ได้ถูกอ่าน → ต้อง deploy ใหม่

### วิธีที่ 2: Deploy Edge Function ใหม่

```powershell
cd e:\Web_App\TR-ERP
supabase functions deploy verify-slip
```

**เหตุผล:**
- บางครั้ง Edge Function ต้อง restart หลังตั้งค่า secrets
- Deploy ใหม่จะทำให้ Edge Function อ่าน secrets ใหม่

### วิธีที่ 3: ตั้งค่า Secrets ใหม่

```powershell
# ตรวจสอบ secrets
supabase secrets list

# ตั้งค่า secrets ใหม่ (ถ้าจำเป็น)
supabase secrets set EASYSLIP_API_KEY=your_key_here
supabase secrets set SERVICE_ROLE_KEY=your_key_here
supabase secrets set PROJECT_URL=https://zkzjbhvsltbwbtteihiy.supabase.co

# Deploy ใหม่
supabase functions deploy verify-slip
```

---

## Checklist

### การตรวจสอบ:
- [ ] ดู Logs ใน Supabase Dashboard → Edge Functions → verify-slip → Logs
- [ ] ตรวจสอบว่า `EASYSLIP_API_KEY present: true/false`
- [ ] ตรวจสอบว่า `SERVICE_ROLE_KEY present: true/false`
- [ ] ตรวจสอบว่า `supabase secrets list` แสดง secrets

### การแก้ไข:
- [ ] Deploy Edge Function ใหม่
- [ ] ตั้งค่า Secrets ใหม่ (ถ้าจำเป็น)
- [ ] ทดสอบการเชื่อมต่ออีกครั้ง

---

## หมายเหตุ

⚠️ **สำคัญ:**
- Edge Function อาจต้อง restart หลังตั้งค่า secrets
- Deploy ใหม่จะทำให้ Edge Function อ่าน secrets ใหม่
- ตรวจสอบ Logs เพื่อยืนยันว่า secrets ถูกอ่านได้

📝 **ขั้นตอนต่อไป:**
1. ดู Logs ใน Supabase Dashboard
2. Deploy Edge Function ใหม่
3. ทดสอบการเชื่อมต่ออีกครั้ง
