# แก้ไขปัญหา Password Reset Link ชี้ไปที่ localhost

## ปัญหาที่พบ

เมื่อคลิก link reset password จาก email แล้วเกิด error:
- **"localhost ปฏิเสธการเชื่อมต่อ"** (ERR_CONNECTION_REFUSED)
- **สาเหตุ:** Link ใน email ชี้ไปที่ `http://localhost:5173` แต่ development server ไม่ได้รันอยู่

---

## วิธีแก้ไข

### วิธีที่ 1: รัน Development Server (สำหรับการทดสอบ)

1. **รัน Development Server:**
   ```powershell
   cd e:\Web_App\TR-ERP
   npm run dev
   ```

2. **รอให้ server รันเสร็จ:**
   - ควรเห็นข้อความว่า "Local: http://localhost:5173"
   - หรือ port อื่นตามที่ตั้งค่าไว้

3. **คลิก link reset password อีกครั้ง:**
   - เปิด email อีกครั้ง
   - คลิก link reset password
   - ตอนนี้ควรเข้าได้แล้ว

4. **Reset Password:**
   - ตั้ง password ใหม่
   - Login ด้วย password ใหม่

### วิธีที่ 2: แก้ไข Redirect URL ใน Supabase (แนะนำสำหรับ Production)

**ถ้าต้องการใช้ URL จริง (ไม่ใช่ localhost):**

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ `zkzjbhvsltbwbtteihiy`

2. **ไปที่ Authentication → URL Configuration:**
   - คลิกที่เมนู **Authentication** ด้านซ้าย
   - คลิกที่ **URL Configuration**

3. **แก้ไข Site URL:**
   - **Site URL:** เปลี่ยนจาก `http://localhost:5173` เป็น URL จริงของคุณ
     - เช่น: `https://your-domain.com`
     - หรือ: `https://your-app.vercel.app`
   
4. **แก้ไข Redirect URLs:**
   - เพิ่ม URL ที่ต้องการให้ redirect ไป:
     - `https://your-domain.com/**`
     - `https://your-app.vercel.app/**`
   - หรือเก็บ `http://localhost:5173/**` ไว้สำหรับ development

5. **บันทึกการตั้งค่า:**
   - คลิก **Save**

6. **ขอ Reset Password ใหม่:**
   - ไปที่หน้า Login
   - คลิก "Forgot password?" อีกครั้ง
   - ใส่ email
   - ตรวจสอบ email ใหม่ (link จะชี้ไปที่ URL ที่ตั้งค่าไว้)

### วิธีที่ 3: ใช้ Supabase Dashboard เพื่อ Reset Password

**ถ้าไม่ต้องการรัน development server:**

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ `zkzjbhvsltbwbtteihiy`

2. **ไปที่ Authentication → Users:**
   - คลิกที่เมนู **Authentication** ด้านซ้าย
   - คลิกที่ **Users**

3. **หา User ที่ต้องการ:**
   - ค้นหา user ด้วย email
   - คลิกที่ user

4. **Reset Password:**
   - คลิกที่ปุ่ม **"Send password reset email"** หรือ **"Reset password"**
   - หรือแก้ไข password โดยตรง (ถ้ามีสิทธิ์)

---

## Checklist การแก้ไข

### วิธีที่ 1: รัน Development Server
- [ ] รัน `npm run dev`
- [ ] รอให้ server รันเสร็จ
- [ ] คลิก link reset password อีกครั้ง
- [ ] Reset password
- [ ] Login ด้วย password ใหม่

### วิธีที่ 2: แก้ไข Redirect URL
- [ ] เข้า Supabase Dashboard
- [ ] ไปที่ Authentication → URL Configuration
- [ ] แก้ไข Site URL
- [ ] เพิ่ม Redirect URLs
- [ ] บันทึกการตั้งค่า
- [ ] ขอ Reset Password ใหม่
- [ ] ตรวจสอบ email และคลิก link
- [ ] Reset password

### วิธีที่ 3: ใช้ Supabase Dashboard
- [ ] เข้า Supabase Dashboard
- [ ] ไปที่ Authentication → Users
- [ ] หา User ที่ต้องการ
- [ ] Reset Password

---

## ข้อมูลสำคัญ

### Development Server:
- **URL:** `http://localhost:5173` (หรือ port อื่นตามที่ตั้งค่า)
- **คำสั่งรัน:** `npm run dev`

### Supabase Auth Settings:
- **Site URL:** ตั้งค่าใน Authentication → URL Configuration
- **Redirect URLs:** ตั้งค่าใน Authentication → URL Configuration

---

## Troubleshooting

### ปัญหา: รัน `npm run dev` แล้วยังเข้าไม่ได้

**ตรวจสอบ:**
1. Port ถูกใช้โดยโปรแกรมอื่นหรือไม่
2. Firewall บล็อคหรือไม่
3. มี error ใน terminal หรือไม่

**วิธีแก้:**
- ตรวจสอบ port ที่ใช้ (ดูใน terminal)
- ลองใช้ port อื่น: `npm run dev -- --port 3000`
- ตรวจสอบ firewall settings

### ปัญหา: แก้ไข Redirect URL แล้วยังไม่ได้

**ตรวจสอบ:**
1. บันทึกการตั้งค่าแล้วหรือไม่
2. URL ถูกต้องหรือไม่ (ต้องมี `https://` หรือ `http://`)
3. มี wildcard `/**` หรือไม่

**วิธีแก้:**
- ตรวจสอบการตั้งค่าอีกครั้ง
- ลองขอ Reset Password ใหม่
- ตรวจสอบ email ใหม่

---

## หมายเหตุ

⚠️ **สำคัญ:**
- สำหรับ Development: ใช้ `http://localhost:5173`
- สำหรับ Production: ใช้ URL จริง (เช่น `https://your-domain.com`)

📝 **คำแนะนำ:**
- ตั้งค่า Redirect URLs ให้รองรับทั้ง development และ production
- ใช้ Supabase Dashboard เพื่อ Reset Password ถ้าไม่ต้องการรัน development server
