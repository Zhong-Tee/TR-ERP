/**
 * Purchase API: Centralized queries for PR / PO / GR / Sample
 * All read operations use nested select (1 API call).
 * All complex write operations use RPC functions (1 API call).
 */
import { supabase } from './supabase'
import { fetchAllSupabasePages } from './supabasePagination'
import type {
  InventoryPR,
  InventoryPO,
  InventoryPOItem,
  InventoryGR,
  InventorySample,
  Product,
} from '../types'

/* ──────────────── User Display Names ──────────────── */

export async function loadUserDisplayNames(userIds: string[]): Promise<Record<string, string>> {
  const unique = [...new Set(userIds.filter(Boolean))]
  if (!unique.length) return {}
  const { data, error } = await supabase
    .from('us_users')
    .select('id, username, email')
    .in('id', unique)
  if (error) throw error
  const map: Record<string, string> = {}
  for (const u of (data || [])) {
    map[u.id] = u.username || u.email || u.id
  }
  return map
}

/* ──────────────── Products ──────────────── */

const PRODUCT_PURCHASE_SAFE_COLUMNS = 'id, product_code, product_name, seller_name, product_name_cn, order_point, order_point_days, product_category, product_type, rubber_code, storage_location, safety_stock, unit_name, unit_multiplier, is_hold, hold_reason, hold_at, hold_by, is_active, created_at, updated_at'

export async function loadProductsWithLastPrice(includeCost = false): Promise<(Product & { last_price?: number | null })[]> {
  const data = await fetchAllSupabasePages((from, to) => supabase
    .from('pr_products')
    .select(includeCost ? '*, v_product_last_price(last_price)' : PRODUCT_PURCHASE_SAFE_COLUMNS)
    .eq('is_active', true)
    .order('product_code')
    .order('id')
    .range(from, to))
  return data.map((p: any) => ({
    ...p,
    last_price: p.v_product_last_price?.last_price ?? null,
  }))
}

/* ──────────────── Stock Balances ──────────────── */

export async function loadStockBalances(): Promise<Record<string, number>> {
  const data = await fetchAllSupabasePages<{ product_id: string; on_hand: number | null }>((from, to) => supabase
    .from('inv_stock_balances')
    .select('product_id, on_hand')
    .order('product_id')
    .range(from, to))
  const map: Record<string, number> = {}
  for (const row of data) {
    map[row.product_id] = Number(row.on_hand) || 0
  }
  return map
}

export interface PendingPOProductInfo {
  pending_qty: number
  po_details: Array<{
    po_id: string
    po_no: string
    status: string
    pending_qty: number
    expected_arrival_date?: string | null
  }>
}

export interface ActivePRProductInfo {
  requested_qty: number
  pr_details: Array<{
    pr_id: string
    pr_no: string
    status: string
    qty: number
  }>
}

/** PRs that still need attention before purchasing: pending, or approved without a PO. */
export async function loadActivePRByProduct(): Promise<Record<string, ActivePRProductInfo>> {
  const { data, error } = await supabase
    .from('inv_pr')
    .select('id, pr_no, status, inv_po(id), inv_pr_items(product_id, qty)')
    .in('status', ['pending', 'approved'])
  if (error) throw error

  const map: Record<string, ActivePRProductInfo> = {}
  for (const pr of (data || []) as any[]) {
    // Approved PRs already converted to a PO are covered by the pending-PO warning.
    if (Array.isArray(pr.inv_po) && pr.inv_po.length > 0) continue
    for (const item of (pr.inv_pr_items || []) as any[]) {
      if (!item.product_id) continue
      const qty = Number(item.qty) || 0
      const current = map[item.product_id] || { requested_qty: 0, pr_details: [] }
      current.requested_qty += qty
      current.pr_details.push({
        pr_id: pr.id,
        pr_no: pr.pr_no,
        status: pr.status,
        qty,
      })
      map[item.product_id] = current
    }
  }
  return map
}

export async function loadPendingPOByProduct(): Promise<Record<string, PendingPOProductInfo>> {
  const { data, error } = await supabase.rpc('rpc_get_pending_po_details_by_product')
  if (error) throw error
  const map: Record<string, PendingPOProductInfo> = {}
  for (const row of (data || []) as any[]) {
    map[row.product_id] = {
      pending_qty: Number(row.pending_qty) || 0,
      po_details: Array.isArray(row.po_details)
        ? row.po_details.map((detail: any) => ({ ...detail, pending_qty: Number(detail.pending_qty) || 0 }))
        : [],
    }
  }
  return map
}

/* ──────────────── PR (Purchase Requisition) ──────────────── */

export interface PRListFilters {
  status?: string
  search?: string
  dateFrom?: string
  dateTo?: string
  prType?: string
  excludePrType?: string
}

export async function loadPRList(filters: PRListFilters = {}, includeCost = false): Promise<InventoryPR[]> {
  let q = supabase
    .from('inv_pr')
    .select(includeCost ? '*, inv_pr_items(id, qty, estimated_price, last_purchase_price), inv_po(id, po_no, status)' : '*, inv_pr_items(id, qty), inv_po(id, po_no, status)')
    .order('created_at', { ascending: false })

  if (filters.status && filters.status !== 'all') {
    q = q.eq('status', filters.status)
  }
  if (filters.search) {
    q = q.ilike('pr_no', `%${filters.search}%`)
  }
  if (filters.dateFrom) {
    q = q.gte('created_at', filters.dateFrom)
  }
  if (filters.dateTo) {
    q = q.lte('created_at', filters.dateTo + 'T23:59:59')
  }
  if (filters.prType && filters.prType !== 'all') {
    q = q.eq('pr_type', filters.prType)
  }
  if (filters.excludePrType) {
    q = q.neq('pr_type', filters.excludePrType)
  }

  const { data, error } = await q
  if (error) throw error
  return (data || []) as unknown as InventoryPR[]
}

export async function loadPRDetail(prId: string, includeCost = false) {
  const { data, error } = await supabase
    .from('inv_pr')
    .select(includeCost ? `
      *,
      inv_pr_items(
        *,
        pr_products(id, product_code, product_name, product_name_cn, seller_name, product_category, product_type, unit_cost, storage_location, order_point, unit_name)
      ),
      inv_po(id, po_no, status)
    ` : `
      *,
      inv_pr_items(
        id, pr_id, product_id, qty, unit, note, created_at,
        pr_products(id, product_code, product_name, product_name_cn, seller_name, product_category, product_type, storage_location, order_point, unit_name)
      ),
      inv_po(id, po_no, status)
    `)
    .eq('id', prId)
    .single()
  if (error) throw error
  return data as unknown as InventoryPR
}

export interface CreatePRInput {
  items: {
    product_id: string
    qty: number
    unit?: string
    estimated_price?: number | null
    note?: string
  }[]
  note?: string
  userId?: string
  prType?: string
  supplierId?: string
  supplierName?: string
}

export async function createPR(input: CreatePRInput) {
  const { data, error } = await supabase.rpc('rpc_create_pr', {
    p_items: input.items,
    p_note: input.note || null,
    p_user_id: input.userId || null,
    p_pr_type: input.prType || 'normal',
    p_supplier_id: input.supplierId || null,
    p_supplier_name: input.supplierName || null,
  })
  if (error) throw error
  return data as { id: string; pr_no: string }
}

export async function approvePR(prId: string, userId: string) {
  const { error } = await supabase.rpc('rpc_approve_pr', {
    p_pr_id: prId,
    p_user_id: userId,
  })
  if (error) throw error
}

export async function rejectPR(prId: string, userId: string, reason: string) {
  const { error } = await supabase.rpc('rpc_reject_pr', {
    p_pr_id: prId,
    p_user_id: userId,
    p_reason: reason,
  })
  if (error) throw error
}

export async function cancelPR(prId: string) {
  const { error } = await supabase
    .from('inv_pr')
    .update({ status: 'cancelled' })
    .eq('id', prId)
    .eq('status', 'pending')
  if (error) throw error
}

export async function cancelApprovedPRWithoutPO(prId: string) {
  const { data: existingPOs, error: poError } = await supabase
    .from('inv_po')
    .select('id')
    .eq('pr_id', prId)
    .limit(1)
  if (poError) throw poError
  if (existingPOs && existingPOs.length > 0) {
    throw new Error('PR นี้ถูกนำไปสร้าง PO แล้ว จึงไม่สามารถยกเลิกได้')
  }

  const { data: cancelledPRs, error: cancelError } = await supabase
    .from('inv_pr')
    .update({ status: 'cancelled' })
    .eq('id', prId)
    .eq('status', 'approved')
    .select('id')
  if (cancelError) throw cancelError
  if (!cancelledPRs || cancelledPRs.length === 0) {
    throw new Error('ไม่สามารถยกเลิก PR ได้ เนื่องจากสถานะรายการมีการเปลี่ยนแปลง')
  }
}

export async function updatePR(input: {
  prId: string
  items: { product_id: string; qty: number; unit?: string; estimated_price?: number | null; note?: string }[]
  note?: string
  prType?: string
  supplierId?: string
  supplierName?: string
}) {
  const { error } = await supabase.rpc('rpc_update_pr', {
    p_pr_id: input.prId,
    p_items: input.items,
    p_note: input.note || null,
    p_pr_type: input.prType || null,
    p_supplier_id: input.supplierId || null,
    p_supplier_name: input.supplierName || null,
  })
  if (error) throw error
}

/* ──────────────── PO (Purchase Order) ──────────────── */

export interface POListFilters {
  status?: string
  search?: string
  dateFrom?: string
  dateTo?: string
}

export async function loadPOList(filters: POListFilters = {}, includeCost = false): Promise<InventoryPO[]> {
  let q = supabase
    .from('inv_po')
    .select(includeCost
      ? '*, inv_pr(pr_no, pr_type), inv_po_items(id, qty, unit_price)'
      : 'id, po_no, pr_id, status, supplier_id, supplier_name, created_by, ordered_by, ordered_at, expected_arrival_date, note, created_at, updated_at, inv_pr(pr_no, pr_type), inv_po_items(id, qty)')
    .order('created_at', { ascending: false })

  if (filters.status && filters.status !== 'all') {
    q = q.eq('status', filters.status)
  }
  if (filters.search) {
    q = q.ilike('po_no', `%${filters.search}%`)
  }
  if (filters.dateFrom) {
    q = q.gte('created_at', filters.dateFrom)
  }
  if (filters.dateTo) {
    q = q.lte('created_at', filters.dateTo + 'T23:59:59')
  }

  const { data, error } = await q
  if (error) throw error
  return (data || []) as unknown as InventoryPO[]
}

export async function loadPODetail(poId: string, includeCost = false) {
  const { data, error } = await supabase
    .from('inv_po')
    .select(includeCost ? `
      *,
      inv_pr(pr_no, note),
      inv_po_items(
        *,
        pr_products(id, product_code, product_name, product_name_cn, seller_name, product_category, unit_name)
      )
    ` : `
      id, po_no, pr_id, status, supplier_id, supplier_name, created_by, ordered_by, ordered_at, expected_arrival_date, note, created_at, updated_at,
      inv_pr(pr_no, note),
      inv_po_items(id, po_id, product_id, qty, unit, note, qty_received_total, resolution_type, resolution_qty, resolution_note, resolved_at, resolved_by, created_at,
        pr_products(id, product_code, product_name, product_name_cn, seller_name, product_category, unit_name))
    `)
    .eq('id', poId)
    .single()
  if (error) throw error
  return data as unknown as InventoryPO
}

export interface ConvertPRtoPOInput {
  prId: string
  supplierId?: string | null
  supplierName?: string | null
  prices?: { product_id: string; unit_price: number }[]
  note?: string
  userId?: string
  expectedArrivalDate?: string | null
}

export async function convertPRtoPO(input: ConvertPRtoPOInput) {
  const { data, error } = await supabase.rpc('rpc_convert_pr_to_po', {
    p_pr_id: input.prId,
    p_supplier_id: input.supplierId || null,
    p_supplier_name: input.supplierName || null,
    p_prices: input.prices || [],
    p_note: input.note || null,
    p_user_id: input.userId || null,
  })
  if (error) throw error
  const result = data as { id: string; po_no: string; total_amount: number }

  if (input.expectedArrivalDate) {
    await supabase.from('inv_po').update({ expected_arrival_date: input.expectedArrivalDate }).eq('id', result.id)
  }

  return result
}

export async function markPOOrdered(poId: string, userId: string) {
  const { error } = await supabase.rpc('rpc_mark_po_ordered', {
    p_po_id: poId,
    p_user_id: userId,
  })
  if (error) throw error
}

export async function updatePOShipping(poId: string, shipping: {
  intl_shipping_method?: string
  intl_shipping_weight?: number
  intl_shipping_cbm?: number
  intl_shipping_cost?: number
  intl_shipping_currency?: string
  intl_exchange_rate?: number
  intl_shipping_cost_thb?: number
  grand_total?: number
}) {
  const { error } = await supabase
    .from('inv_po')
    .update(shipping)
    .eq('id', poId)
  if (error) throw error
}

export async function recalcPOLandedCost(poId: string) {
  const { error } = await supabase.rpc('rpc_recalc_po_landed_cost', { p_po_id: poId })
  if (error) throw error
}

export async function updatePO(input: {
  poId: string
  note?: string
  expectedArrivalDate?: string | null
  items: { item_id: string; unit_price: number | null; qty?: number; note?: string }[]
}) {
  const { data, error } = await supabase.rpc('rpc_update_po', {
    p_po_id: input.poId,
    p_note: input.note ?? null,
    p_expected_arrival_date: input.expectedArrivalDate || null,
    p_items: input.items,
  })
  if (error) throw error
  return data as { total_amount: number }
}

export interface POCostCorrectionResult {
  success: boolean
  correction_id: string
  correction_no: string
  changed_count: number
  new_total_amount: number
  new_grand_total: number
  inventory_value_delta: number
  consumed_cost_delta: number
  items: {
    item_id: string
    product_code: string
    old_unit_price: number
    new_unit_price: number
    qty_received: number
    qty_remaining: number
    qty_consumed: number
    inventory_value_delta: number
    consumed_cost_delta: number
  }[]
}

export interface POCostCorrectionHistory {
  id: string
  correction_no: string
  reason: string
  old_total_amount: number
  new_total_amount: number
  old_grand_total: number
  new_grand_total: number
  inventory_value_delta: number
  consumed_cost_delta: number
  corrected_by: string | null
  created_at: string
  inv_po_cost_correction_items: POCostCorrectionResult['items']
}

export async function correctPOUnitCosts(input: {
  poId: string
  reason: string
  items: { item_id: string; new_unit_price: number }[]
}) {
  const { data, error } = await supabase.rpc('rpc_correct_po_unit_costs', {
    p_po_id: input.poId,
    p_reason: input.reason,
    p_items: input.items,
  })
  if (error) throw error
  return data as POCostCorrectionResult
}

export async function loadPOCostCorrectionHistory(poId: string) {
  const { data, error } = await supabase
    .from('inv_po_cost_corrections')
    .select('*, inv_po_cost_correction_items(*)')
    .eq('po_id', poId)
    .order('created_at', { ascending: false })
  if (error) throw error
  return (data || []) as unknown as POCostCorrectionHistory[]
}

export async function updatePONonFinancial(input: {
  poId: string
  note?: string
  expectedArrivalDate?: string | null
  items: { item_id: string; qty?: number; note?: string }[]
}) {
  const { data, error } = await supabase.rpc('rpc_update_po_nonfinancial', {
    p_po_id: input.poId,
    p_note: input.note ?? null,
    p_expected_arrival_date: input.expectedArrivalDate || null,
    p_items: input.items,
  })
  if (error) throw error
  return data as { total_amount: number }
}

export async function updatePOExpectedArrivalDate(input: {
  poId: string
  expectedArrivalDate: string
  userId?: string
}) {
  const { error } = await supabase.rpc('rpc_update_po_expected_arrival_date', {
    p_po_id: input.poId,
    p_expected_arrival_date: input.expectedArrivalDate,
    p_user_id: input.userId || null,
  })
  if (error) throw error
}

/* ──────────────── GR (Goods Receipt) ──────────────── */

export interface GRListFilters {
  status?: string
  search?: string
  dateFrom?: string
  dateTo?: string
}

export async function loadGRList(filters: GRListFilters = {}, includeCost = false): Promise<InventoryGR[]> {
  let q = supabase
    .from('inv_gr')
    .select(includeCost
      ? '*, inv_po(po_no, status, expected_arrival_date, intl_shipping_cost_thb, inv_pr(pr_type), inv_po_items(resolution_type, qty_received_total)), inv_gr_items(id, qty_ordered, qty_received)'
      : 'id, gr_no, po_id, status, received_by, received_at, dom_shipping_company, note, shortage_note, created_at, updated_at, inv_po(po_no, status, expected_arrival_date, inv_pr(pr_type), inv_po_items(resolution_type, qty_received_total)), inv_gr_items(id, qty_ordered, qty_received)')
    .order('created_at', { ascending: false })

  if (filters.status && filters.status !== 'all') {
    q = q.eq('status', filters.status)
  }
  if (filters.search) {
    q = q.ilike('gr_no', `%${filters.search}%`)
  }
  if (filters.dateFrom) {
    q = q.gte('created_at', filters.dateFrom)
  }
  if (filters.dateTo) {
    q = q.lte('created_at', filters.dateTo + 'T23:59:59')
  }

  const { data, error } = await q
  if (error) throw error
  return (data || []) as unknown as InventoryGR[]
}

export async function loadGRDetail(grId: string, includeCost = false) {
  const { data, error } = await supabase
    .from('inv_gr')
    .select(includeCost ? `
      *,
      inv_po(
        po_no,
        note,
        expected_arrival_date,
        intl_shipping_cost_thb,
        inv_pr(pr_no, note),
        inv_po_items(product_id, qty, qty_received_total, unit_price)
      ),
      inv_gr_items(
        *,
        pr_products(id, product_code, product_name, product_name_cn, seller_name, unit_name),
        inv_gr_item_images(*)
      )
    ` : `
      id, gr_no, po_id, status, received_by, received_at, dom_shipping_company, note, shortage_note, created_at, updated_at,
      inv_po(po_no, note, expected_arrival_date, inv_pr(pr_no, note), inv_po_items(product_id, qty, qty_received_total)),
      inv_gr_items(id, gr_id, product_id, qty_ordered, qty_received, shortage_note, created_at,
        pr_products(id, product_code, product_name, product_name_cn, seller_name, unit_name), inv_gr_item_images(*))
    `)
    .eq('id', grId)
    .single()
  if (error) throw error
  return data as unknown as InventoryGR
}

export interface ReceiveGRInput {
  poId: string
  items: {
    product_id: string
    qty_received: number
    qty_ordered: number
    shortage_note?: string
    images?: {
      storage_bucket?: string
      storage_path: string
      file_name?: string
      mime_type?: string
      size_bytes?: number
      sort_order?: number
    }[]
  }[]
  shipping?: {
    dom_shipping_company?: string
    dom_shipping_cost?: number
    note?: string
    shortage_note?: string
  }
  userId?: string
}

export async function receiveGR(input: ReceiveGRInput) {
  const { data, error } = await supabase.rpc('rpc_receive_gr', {
    p_po_id: input.poId,
    p_items: input.items,
    p_shipping: input.shipping || {},
    p_user_id: input.userId || null,
  })
  if (error) throw error
  return data as { id: string; gr_no: string; status: string; total_received: number }
}

/* ──────────────── PO items for GR form ──────────────── */

export async function loadPOItemsForGR(poId: string) {
  const { data, error } = await supabase
    .from('inv_po_items')
    .select('*, pr_products(id, product_code, product_name, product_name_cn, unit_name)')
    .eq('po_id', poId)
  if (error) throw error
  return (data || []) as unknown as InventoryPOItem[]
}

export async function loadPODetailWithItems(poId: string) {
  const { data, error } = await supabase
    .from('inv_po')
    .select(`
      *,
      inv_pr(pr_no),
      inv_po_items(
        *,
        pr_products(id, product_code, product_name, product_name_cn, seller_name, product_category, unit_name)
      )
    `)
    .eq('id', poId)
    .single()
  if (error) throw error
  return data as unknown as InventoryPO
}

/* ──────────────── Samples ──────────────── */

export interface SampleListFilters {
  status?: string
  search?: string
}

export async function loadSamples(filters: SampleListFilters = {}): Promise<InventorySample[]> {
  let q = supabase
    .from('inv_samples')
    .select('*, inv_sample_items(id)')
    .order('created_at', { ascending: false })

  if (filters.status && filters.status !== 'all') {
    q = q.eq('status', filters.status)
  }
  if (filters.search) {
    q = q.ilike('sample_no', `%${filters.search}%`)
  }

  const { data, error } = await q
  if (error) throw error
  return (data || []) as unknown as InventorySample[]
}

export type SampleActiveStatus = 'pending_receipt' | 'received' | 'testing'

export async function loadSampleStatusCounts(): Promise<Record<SampleActiveStatus, number>> {
  const { data, error } = await supabase
    .from('inv_samples')
    .select('status')
    .in('status', ['pending_receipt', 'received', 'testing'])
  if (error) throw error

  const counts: Record<SampleActiveStatus, number> = {
    pending_receipt: 0,
    received: 0,
    testing: 0,
  }
  for (const row of data || []) {
    if (row.status in counts) counts[row.status as SampleActiveStatus] += 1
  }
  return counts
}

export async function loadSampleDetail(sampleId: string) {
  const { data, error } = await supabase
    .from('inv_samples')
    .select(`
      *,
      inv_sample_items(
        *,
        pr_products:pr_products!inv_sample_items_product_id_fkey(id, product_code, product_name, product_name_cn)
      )
    `)
    .eq('id', sampleId)
    .single()
  if (error) throw error
  return data as unknown as InventorySample
}

export interface CreateSampleInput {
  items: {
    product_name_manual?: string
    image_url?: string
    qty: number
    note?: string
  }[]
  sampleLabel: string
  note?: string
  userId?: string
  receiptStatus: 'pending_receipt' | 'received'
}

export async function createSample(input: CreateSampleInput) {
  if (input.items.length !== 1) throw new Error('รับสินค้าตัวอย่างได้ครั้งละ 1 รายการเท่านั้น')
  const { data, error } = await supabase.rpc('rpc_create_sample', {
    p_items: input.items,
    p_sample_label: input.sampleLabel,
    p_note: input.note || null,
    p_user_id: input.userId || null,
    p_receipt_status: input.receiptStatus,
  })
  if (error) throw error
  return data as { id: string; sample_no: string }
}

export interface UpdateSampleInput extends CreateSampleInput {
  sampleId: string
  items: (CreateSampleInput['items'][number] & { id?: string })[]
}

export async function updateSample(input: UpdateSampleInput) {
  const { error } = await supabase.rpc('rpc_update_sample', {
    p_sample_id: input.sampleId,
    p_items: input.items,
    p_sample_label: input.sampleLabel,
    p_note: input.note || null,
    p_receipt_status: input.receiptStatus,
  })
  if (error) throw error
}

export async function receivePendingSample(sampleId: string, userId?: string) {
  const { error } = await supabase
    .from('inv_samples')
    .update({ status: 'received', received_at: new Date().toISOString(), received_by: userId || null })
    .eq('id', sampleId)
    .eq('status', 'pending_receipt')
  if (error) throw error
}

export async function updateSampleTest(
  sampleId: string,
  status: 'testing' | 'approved' | 'rejected',
  opts?: {
    userId?: string
    testingByName?: string
    testNote?: string
    rejectionReason?: string
    itemResults?: { item_id: string; result: string; note?: string }[]
  }
) {
  const { error } = await supabase.rpc('rpc_update_sample_test', {
    p_sample_id: sampleId,
    p_status: status,
    p_user_id: opts?.userId || null,
    p_testing_by_name: opts?.testingByName || null,
    p_test_note: opts?.testNote || null,
    p_rejection_reason: opts?.rejectionReason || null,
    p_item_results: opts?.itemResults || [],
  })
  if (error) throw error
}

export async function convertSampleToProduct(input: {
  sampleId: string
  itemId: string
  productCode: string
  productName: string
  productNameCn?: string
  productType?: string
  productCategory?: string
  sellerName?: string
  userId?: string
}) {
  const { data, error } = await supabase.rpc('rpc_convert_sample_to_product', {
    p_sample_id: input.sampleId,
    p_item_id: input.itemId,
    p_product_code: input.productCode,
    p_product_name: input.productName,
    p_product_name_cn: input.productNameCn || null,
    p_product_type: input.productType || 'FG',
    p_product_category: input.productCategory || null,
    p_seller_name: input.sellerName || null,
    p_user_id: input.userId || null,
  })
  if (error) throw error
  return data as string
}

export async function getNextProductCode(productType: 'FG' | 'RM') {
  const { data, error } = await supabase.rpc('rpc_get_next_product_code', {
    p_product_type: productType,
  })
  if (error) throw error
  return String(data || '')
}

export async function createSeller(input: { name: string; nameCn?: string }) {
  const { data, error } = await supabase.rpc('rpc_create_pr_seller', {
    p_name: input.name.trim(),
    p_name_cn: input.nameCn?.trim() || null,
  })
  if (error) throw error
  return data as { id: string; name: string; name_cn: string | null }
}

export async function loadProductCategoryOptions(): Promise<string[]> {
  const { data, error } = await supabase
    .from('pr_products')
    .select('product_category')
    .not('product_category', 'is', null)
    .order('product_category')
  if (error) throw error
  return [...new Set((data || []).map((d: any) => String(d.product_category || '').trim()).filter(Boolean))]
}

/* ──────────────── Purchase Badge Counts ──────────────── */

export async function loadPurchaseBadgeCounts(): Promise<{ pr_pending: number; pr_approved_no_po: number; po_waiting_gr: number; machinery_pending: number }> {
  const [{ data, error }, machineryRes] = await Promise.all([
    supabase.rpc('get_purchase_badge_counts'),
    supabase.from('inv_pr').select('*', { count: 'exact', head: true }).eq('status', 'pending').eq('pr_type', 'machinery'),
  ])
  if (error) throw error
  if (machineryRes.error) throw machineryRes.error
  const base = data as { pr_pending: number; pr_approved_no_po: number; po_waiting_gr: number }
  const machineryPending = machineryRes.count || 0
  return { ...base, pr_pending: Math.max(0, (base.pr_pending || 0) - machineryPending), machinery_pending: machineryPending }
}

/* ──────────────── Sellers ──────────────── */

export async function loadSellers() {
  const { data, error } = await supabase
    .from('pr_sellers')
    .select('id, name, name_cn, seller_type')
    .eq('is_active', true)
    .order('name')
  if (error) throw error
  return data || []
}

/* ──────────────── Approved PRs without PO ──────────────── */

export async function loadApprovedPRsWithoutPO(): Promise<InventoryPR[]> {
  const { data: allApproved, error: prErr } = await supabase
    .from('inv_pr')
    .select('*, inv_pr_items(id, product_id, qty, unit, estimated_price, pr_products(product_code, product_name, unit_name))')
    .eq('status', 'approved')
    .order('created_at', { ascending: false })
  if (prErr) throw prErr

  const { data: allPOs, error: poErr } = await supabase
    .from('inv_po')
    .select('pr_id')
    .not('pr_id', 'is', null)
  if (poErr) throw poErr

  const usedPrIds = new Set((allPOs || []).map((p: any) => p.pr_id))
  return ((allApproved || []) as unknown as InventoryPR[]).filter((pr) => !usedPrIds.has(pr.id))
}

/* ──────────────── POs available for GR (ordered + partial) ──────────────── */

export async function loadPOsForGR(): Promise<{ newPOs: InventoryPO[]; partialPOs: InventoryPO[] }> {
  const { data: allOrdered, error: poErr } = await supabase
    .from('inv_po')
    .select('*, inv_pr(pr_no, note, supplier_name), inv_po_items(id, product_id, qty, qty_received_total, unit, unit_price, note, pr_products(product_code, product_name, unit_name))')
    .in('status', ['ordered', 'partial'])
    .order('created_at', { ascending: false })
  if (poErr) throw poErr

  const { data: allGRs, error: grErr } = await supabase
    .from('inv_gr')
    .select('po_id')
    .not('po_id', 'is', null)
  if (grErr) throw grErr

  const usedPoIds = new Set((allGRs || []).map((g: any) => g.po_id))
  const all = (allOrdered || []) as unknown as InventoryPO[]

  const newPOs = all.filter((po) => po.status === 'ordered' && !usedPoIds.has(po.id))
  const partialPOs = all.filter((po) => po.status === 'partial')

  return { newPOs, partialPOs }
}

/* ──────────────── GRs for a specific PO (history) ──────────────── */

export async function loadGRsForPO(poId: string): Promise<InventoryGR[]> {
  const { data, error } = await supabase
    .from('inv_gr')
    .select('*, inv_gr_items(id, product_id, qty_ordered, qty_received, qty_shortage)')
    .eq('po_id', poId)
    .order('created_at', { ascending: false })
  if (error) throw error
  return (data || []) as unknown as InventoryGR[]
}

/* ──────────────── Resolve PO shortage ──────────────── */

export interface ResolveShortageInput {
  poId: string
  resolutions: {
    po_item_id: string
    resolution_type: string
    resolution_qty: number
    resolution_note?: string
  }[]
  userId?: string
}

export async function resolveShortage(input: ResolveShortageInput) {
  const { data, error } = await supabase.rpc('rpc_resolve_po_shortage', {
    p_po_id: input.poId,
    p_resolutions: input.resolutions,
    p_user_id: input.userId || null,
  })
  if (error) throw error
  return data as { success: boolean; updated_count: number; po_status: string }
}
