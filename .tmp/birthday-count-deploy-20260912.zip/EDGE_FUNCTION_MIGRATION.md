# คู่มือจัดการ Edge Functions เก่าและใหม่

## สถานะปัจจุบัน

- ✅ มี Edge Function เก่า: `easyslip-me` (ไม่ถูกใช้งานในโค้ดปัจจุบัน)
- ✅ โค้ดปัจจุบันใช้: `verify-slip` (ต้อง Deploy ใหม่)
- 📋 Project Reference: `zkzjbhvsltbwbtteihiy`

---

## วิธีจัดการ Edge Functions

### ทางเลือกที่ 1: ลบ Function เก่าและ Deploy ใหม่ (แนะนำ)

#### ขั้นตอนที่ 1: ลบ Function เก่า `easyslip-me`

1. **เข้า Supabase Dashboard:**
   - ไปที่ https://supabase.com/dashboard
   - เลือกโปรเจกต์ `zkzjbhvsltbwbtteihiy`

2. **ไปที่ Edge Functions:**
   - คลิกที่เมนู **Edge Functions** ด้านซ้าย

3. **ลบ Function เก่า:**
   - คลิกที่ function `easyslip-me`
   - คลิกที่ปุ่ม **Delete** หรือ **Remove**
   - ยืนยันการลบ

#### ขั้นตอนที่ 2: Deploy Function ใหม่ `verify-slip`

**วิธีที่ 1: ใช้ Dashboard**

1. **ไปที่ Edge Functions:**
   - คลิกที่เมนู **Edge Functions** ด้านซ้าย

2. **Deploy Function ใหม่:**
   - คลิกที่ปุ่ม **"Deploy a new function"**
   - เลือก **"Deploy from local"** หรือ **"Upload"**
   - อัปโหลดโฟลเดอร์ `supabase/functions/verify-slip`
   - หรือใช้ CLI (แนะนำ)

**วิธีที่ 2: ใช้ Supabase CLI (แนะนำ)**

```powershell
# ไปที่โฟลเดอร์โปรเจกต์
cd e:\Web_App\TR-ERP

# ตรวจสอบว่า link โปรเจกต์แล้วหรือยัง
supabase link --project-ref zkzjbhvsltbwbtteihiy

# Deploy function verify-slip
supabase functions deploy verify-slip
```

---

### ทางเลือกที่ 2: เก็บ Function เก่าไว้ (ไม่ลบ)

**ถ้าไม่ต้องการลบ function เก่า:**
- ไม่เป็นปัญหา function เก่าจะไม่ถูกเรียกใช้
- แค่ Deploy function ใหม่ `verify-slip` ได้เลย
- Function เก่าจะยังอยู่ในรายการแต่ไม่ถูกใช้งาน

---

### ทางเลือกที่ 3: เปลี่ยนชื่อ Function เก่า

**ถ้าต้องการใช้โค้ดเดิมของ `easyslip-me`:**

1. **แก้ไขโค้ดให้รองรับ `verify-slip`:**
   - ตรวจสอบว่า function `easyslip-me` มีโค้ดอะไรบ้าง
   - ถ้าต้องการให้ทำงานเหมือนกัน ให้ Deploy function ใหม่ `verify-slip` แทน

2. **หรือแก้ไขโค้ดให้เรียกใช้ `easyslip-me`:**
   - ต้องแก้ไขทุกที่ที่เรียกใช้ `verify-slip` ให้เป็น `easyslip-me`
   - **ไม่แนะนำ** เพราะโค้ดปัจจุบันใช้ `verify-slip` ทั้งหมด

---

## Checklist

### การจัดการ Function เก่า:
- [ ] ตัดสินใจว่าจะลบ `easyslip-me` หรือไม่
- [ ] ลบ function เก่า (ถ้าต้องการ)
- [ ] ตรวจสอบว่าไม่มีโค้ดเรียกใช้ `easyslip-me` แล้ว

### การ Deploy Function ใหม่:
- [x] Link โปรเจกต์ (สำเร็จแล้ว)
- [x] Deploy function `verify-slip` (สำเร็จแล้ว)
- [ ] ตรวจสอบว่า Deploy สำเร็จ (ตรวจสอบใน Dashboard)
- [ ] ตรวจสอบ Logs ไม่มี errors

### การตั้งค่า Secrets:
- [ ] ตั้งค่า `EASYSLIP_API_KEY`
- [ ] ตั้งค่า `SERVICE_ROLE_KEY`
- [ ] ตั้งค่า `SUPABASE_URL`
- [ ] ตรวจสอบ Secrets (`supabase secrets list`)

---

## คำถามที่พบบ่อย

### Q: ต้องลบ function เก่าหรือไม่?
**A:** ไม่จำเป็น แต่แนะนำให้ลบเพื่อความสะอาด ถ้าไม่ใช้แล้ว

### Q: Function เก่าจะส่งผลต่อ function ใหม่หรือไม่?
**A:** ไม่ส่งผล function แต่ละตัวทำงานอิสระกัน

### Q: ถ้า Deploy function ใหม่แล้ว function เก่ายังอยู่ได้ไหม?
**A:** ได้ function แต่ละตัวทำงานแยกกัน ไม่กระทบกัน

### Q: จะรู้ได้อย่างไรว่า function ไหนถูกใช้งาน?
**A:** 
- ตรวจสอบโค้ดในโปรเจกต์ (ใช้ grep หรือ search)
- ดู Logs ใน Dashboard ว่า function ไหนถูกเรียกใช้
- Function ที่ไม่ถูกเรียกใช้จะไม่มี logs

---

## หมายเหตุ

⚠️ **สำคัญ:**
- Function เก่า `easyslip-me` ไม่ได้ถูกใช้งานในโค้ดปัจจุบัน
- โค้ดปัจจุบันใช้ `verify-slip` ทั้งหมด
- ควร Deploy function ใหม่ `verify-slip` ให้ตรงกับโค้ด

📝 **ขั้นตอนแนะนำ:**
1. ลบ function เก่า `easyslip-me` (ถ้าต้องการ)
2. Deploy function ใหม่ `verify-slip`
3. ตั้งค่า Secrets
4. ทดสอบระบบ
